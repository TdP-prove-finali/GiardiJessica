/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers_db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Modelli;
import cash_register_model.Registratori;
import cash_register_model.Tipi_interventi;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class RegisterDAO {
	
	public List<Clienti> elencoClienti(){
		List<Clienti>cl=new LinkedList<Clienti>();
		try{
		String query="select * from clienti ORDER BY denominazione;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 while(res.next()){
			 Clienti c=new Clienti(res.getString("denominazione"),res.getString("via_sede"),res.getString("cap_sede"),res.getString("citta_sede"),res.getString("provincia_sede"),res.getString("cod_fisc"),res.getString("p_iva"));
			 cl.add(c);
			 
		}
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return cl;
			
	}
	
	public void aggiungiCliente(Clienti c){
		
		try{
			String denominazione=c.getDenominazione();
			String viasede=c.getVia_sede().toString();
			String capsede=c.getCap_sede().toString();
			String cittasede=c.getCitta_sede().toString();
			String provincia=c.getProvincia_sede().toString();
			String cod=c.getCod_fisc().toString();
			String piva=c.getP_iva().toString();
		String query="INSERT INTO clienti (denominazione,via_sede,cap_sede,citta_sede,provincia_sede,cod_fisc,p_iva) VALUES (?,?,?,?,?,?,?);";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setString(1, denominazione);
		 statement.setString(2, viasede);
		 statement.setString(3, capsede);
		 statement.setString(4, cittasede);
		 statement.setString(5, provincia);
		 statement.setString(6, cod);
		 statement.setString(7, piva);
		 statement.executeUpdate();

			statement.close();
			conn.close();
			
		}
		catch(MySQLIntegrityConstraintViolationException ex){
		       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
			  Alert alert = new Alert(AlertType.ERROR);  
              alert.setTitle("Chiave duplicata");
              alert.setContentText("Cliente gi� presente nel database!");

              alert.showAndWait();
		     
		   }
		catch(Exception e){
			  Alert alert = new Alert(AlertType.ERROR);  
              alert.setTitle("Dati non validi");
              alert.setContentText("Dati inseriti non validi.");

              alert.showAndWait();
		}
	
			
	}



public void modificaCliente(Clienti c,Clienti cliente){
	
	try{
		String piniz=cliente.getP_iva().toString();
		String denominazione=c.getDenominazione();
		String viasede=c.getVia_sede().toString();
		String capsede=c.getCap_sede().toString();
		String cittasede=c.getCitta_sede().toString();
		String provincia=c.getProvincia_sede().toString();
		String cod=c.getCod_fisc().toString();
		String piva=c.getP_iva().toString();
	String query="UPDATE clienti SET clienti.denominazione= ?, clienti.p_iva= ?, clienti.via_sede= ?, clienti.cap_sede= ?, clienti.citta_sede= ?, clienti.provincia_sede= ?, clienti.cod_fisc= ? WHERE clienti.p_iva= ?;";
	 Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setString(1, denominazione);
	 statement.setString(2, piva);
	 statement.setString(3, viasede);
	 statement.setString(4, capsede);
	 statement.setString(5, cittasede);
	 statement.setString(6, provincia);
	 statement.setString(7, cod);
	 statement.setString(8, piniz);
	 statement.executeUpdate();
   
		statement.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Cliente gi� presente nel database!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
	}
		
}


	public List<Modelli> elencoModelli(){
		List<Modelli>mod=new LinkedList<Modelli>();
		try{
		String query="select * from modelli;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 while(res.next()){
			 Modelli m=new Modelli(res.getString("modello"),res.getString("marchio"),res.getString("logo_tipo"));
			 mod.add(m);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return mod;
			
	}
	
public void aggiungiMdello(Modelli m){
		
		try{
			String mod=m.getModello().toString();
			String marchio=m.getMarchio().toString();
			String logo=m.getLogo_tipo().toString();
			
		String query="INSERT INTO modelli (modello,marchio,logo_tipo) VALUES (?,?,?);";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setString(1, mod);
		 statement.setString(2, marchio);
		 statement.setString(3, logo);
		 statement.executeUpdate();

			statement.close();
			conn.close();
			
		}catch(MySQLIntegrityConstraintViolationException ex){
		       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Chiave duplicata");
           alert.setContentText("Modello gi� presente nel database!");

           alert.showAndWait();
		     
		   }
		catch(Exception e){
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Dati non validi");
           alert.setContentText("Dati inseriti non validi.");

           alert.showAndWait();
		}
	
			
	}

public void modificaModello(Modelli m,Modelli modello){
	
	try{
		String mod=m.getModello().toString();
		String marchio=m.getMarchio().toString();
		String logo=m.getLogo_tipo().toString();
		String modiniz=modello.getModello().toString();
	String query="UPDATE modelli SET modelli.modello=?, modelli.marchio=?, modelli.logo_tipo=? WHERE modelli.modello=?;";
	 Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setString(1, mod);
	 statement.setString(2, marchio);
	 statement.setString(3, logo);
	 statement.setString(4, modiniz);
	 statement.executeUpdate();

		statement.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Modello gi� presente nel database!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
	}

		
}
	

	public List<ClientiReg> elencoClienti_reg(){
		List<ClientiReg>cl=new LinkedList<ClientiReg>();
		try{
		String query="select * from clienti_reg;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 while(res.next()){
			 LocalDate d=res.getDate("ultimo_int").toLocalDate();
			 ClientiReg c=new ClientiReg(res.getString("client"),res.getString("registr"),res.getString("via_reg"),res.getString("cap_reg"),res.getString("citta_reg"),res.getString("provincia_reg"),res.getBoolean("attivo"),d);
			 cl.add(c);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return cl;
			
	}
	
public void aggiungiRegistratore(Clienti c, Registratori r, ClientiReg cr){
		
		try{
			String cliente=c.getP_iva();
			String matricolar=r.getMatricola().toString();
			String modello=r.getModel_rg();
			String via=cr.getVia_reg().get().toString();
			String cap=cr.getCap_reg().get().toString();
			String citta=cr.getCitta_reg().get().toString();
			String prov=cr.getProvincia_reg().get().toString();
			Boolean b=false;
		
			
			Date data=Date.valueOf("1999-01-01");
			 
		String query="INSERT INTO registratori (matricola,model_rg) VALUES (?,?); ";
		String query2="INSERT INTO clienti_reg (client,registr,via_reg,cap_reg,citta_reg,provincia_reg,attivo,ultimo_int) VALUES (?,?,?,?,?,?,?,?);"; 
		Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setString(1, matricolar);
		 statement.setString(2, modello);
		 PreparedStatement statement2=conn.prepareStatement(query2);
		 statement2.setString(1, cliente);
		 statement2.setString(2, matricolar);
		 statement2.setString(3, via);
		 statement2.setString(4, cap);
		 statement2.setString(5, citta);
		 statement2.setString(6, prov);
		 statement2.setBoolean(7, b);
		 statement2.setDate(8, data);
		 statement.executeUpdate();
		 statement2.executeUpdate();

			statement.close();
			statement2.close();
			conn.close();
			
		}catch(MySQLIntegrityConstraintViolationException ex){
		       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Chiave duplicata");
           alert.setContentText("Registratore gi� presente nel database!");

           alert.showAndWait();
		     
		   }
		catch(Exception e){
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Dati non validi");
           alert.setContentText("Dati inseriti non validi.");

           alert.showAndWait();
		}
	
			
	}

public void assegnaRegistratore(Clienti c, Registratori r, ClientiReg cr){
	
	try{
		String cliente=c.getP_iva();
		String matricolar=r.getMatricola().toString();
		String via=cr.getVia_reg().get().toString();
		String cap=cr.getCap_reg().get().toString();
		String citta=cr.getCitta_reg().get().toString();
		String prov=cr.getProvincia_reg().get().toString();
		Boolean b=false;
	
		
		Date data=Date.valueOf("1999-01-01");
		 
	String query2="INSERT INTO clienti_reg (client,registr,via_reg,cap_reg,citta_reg,provincia_reg,attivo,ultimo_int) VALUES (?,?,?,?,?,?,?,?);"; 
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement2=conn.prepareStatement(query2);
	 statement2.setString(1, cliente);
	 statement2.setString(2, matricolar);
	 statement2.setString(3, via);
	 statement2.setString(4, cap);
	 statement2.setString(5, citta);
	 statement2.setString(6, prov);
	 statement2.setBoolean(7, b);
	 statement2.setDate(8, data);
	 statement2.executeUpdate();
		statement2.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Registratore gi� assegnato al cliente!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
	}

		
}

public void modificaRegistratore(Clienti c, Registratori r, ClientiReg cr,ClientiReg iniz){
	
	try{
		String cliente=c.getP_iva();
		String matricolar=r.getMatricola().toString();
		String modello=r.getModel_rg();
		String via=cr.getVia_reg().get().toString();
		String cap=cr.getCap_reg().get().toString();
		String citta=cr.getCitta_reg().get().toString();
		String prov=cr.getProvincia_reg().get().toString();
		String matricolainiz=iniz.getRegistr().get();
		String clientiniz=iniz.getClient().get();
		Boolean attivo=iniz.getAttivo().getValue();
		Date ultimo=Date.valueOf(iniz.getUltimoInt().get());
	
		
	
		 
	String query="UPDATE registratori SET matricola=?,model_rg=? WHERE matricola=?; ";
	String query2="UPDATE clienti_reg SET client=?,registr=?,via_reg=?,cap_reg=?,citta_reg=?,provincia_reg=?,attivo=?,ultimo_int=?  WHERE client=? AND registr=?;"; 
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setString(1, matricolar);
	 statement.setString(2, modello);
	 statement.setString(3, matricolainiz);
	 PreparedStatement statement2=conn.prepareStatement(query2);
	 statement2.setString(1, cliente);
	 statement2.setString(2, matricolar);
	 statement2.setString(3, via);
	 statement2.setString(4, cap);
	 statement2.setString(5, citta);
	 statement2.setString(6, prov);
	 statement2.setBoolean(7, attivo);
	 statement2.setDate(8, ultimo);
	 statement2.setString(9, clientiniz);
	 statement2.setString(10, matricolainiz);
	 statement.executeUpdate();
	 statement2.executeUpdate();

		statement.close();
		statement2.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Registratore gi� assegnato al cliente!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
    
	}

		
}
	
	public List<Interventi> elencoInterventi(){
		List<Interventi> in=new LinkedList<Interventi>();
		try{
		String query="select * from interventi order by data DESC;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 
		 
		 while(res.next()){
			 LocalDate d=res.getDate("data").toLocalDate();
			 Interventi i=new Interventi(d,res.getString("cliente"),res.getString("registratore"),res.getString("tipo_int"), res.getInt("chiusure"),res.getFloat("prezzo"),res.getFloat("costo"),res.getString("note"));
			 in.add(i);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return in;
			
	}
	
	public List<Interventi> elencoIntDelCliente(String piva,String matricola){
		List<Interventi> in=new LinkedList<Interventi>();
	
		try{
			
		String query="select * from interventi where cliente='" + piva + "' AND registratore='" + matricola +"' order by data DESC;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 
		 
		 while(res.next()){
			 LocalDate d=res.getDate("data").toLocalDate();
			 Interventi i=new Interventi(d,res.getString("cliente"),res.getString("registratore"),res.getString("tipo_int"), res.getInt("chiusure"),res.getFloat("prezzo"),res.getFloat("costo"),res.getString("note"));
			 in.add(i);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return in;
			
	}
	
	
public void aggiungiIntervento(Interventi i, ClientiReg cr){
		
		try{
			Date data=Date.valueOf(i.getData().get());
			String cliente=i.getCliente().get();
			String reg=i.getRegistratore().get();
			String tipo=i.getTipo_int().get();
			int chiusure=i.getChiusure().get();
			float prezzo=i.getPrezzo().get();
			float costo=i.getCosto().get();
			String note=i.getNote().get();
			Boolean attivo=cr.getAttivo().get();
			Date dataUltimo=Date.valueOf(cr.getUltimoInt().get());
			
		
			 
		String query="INSERT INTO interventi (data,cliente,registratore, tipo_int,chiusure,prezzo,costo,note) VALUES (?,?,?,?,?,?,?,?);";
       
		String query2="UPDATE clienti_reg SET ultimo_int=?, attivo=? WHERE client=? AND registr=?;";
	 
		Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setDate(1, data);
		 statement.setString(2, cliente);
		 statement.setString(3, reg);
		 statement.setString(4, tipo);
		 statement.setInt(5, chiusure);
		 statement.setFloat(6, prezzo);
		 statement.setFloat(7, costo);
		 statement.setString(8, note);
		 PreparedStatement statement2=conn.prepareStatement(query2);
		 statement2.setDate(1, dataUltimo);
		 statement2.setBoolean(2, attivo);
		 statement2.setString(3, cliente);
		 statement2.setString(4, reg);
		 statement.executeUpdate();
		 statement2.executeUpdate();

			statement.close();
			statement2.close();
			conn.close();
			
		}catch(MySQLIntegrityConstraintViolationException ex){
		       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Chiave duplicata");
           alert.setContentText("Intervento gi� presente nel database!");

           alert.showAndWait();
		     
		   }
		catch(Exception e){
			  Alert alert = new Alert(AlertType.ERROR);  
           alert.setTitle("Dati non validi");
           alert.setContentText("Dati inseriti non validi.");

           alert.showAndWait();
		}
	
			
	}
	
public void modificaIntervento(Interventi i, ClientiReg cr,Interventi vecchioi){
	
	try{
		Date data=Date.valueOf(i.getData().get());
		String cliente=i.getCliente().get();
		String reg=i.getRegistratore().get();
		String tipo=i.getTipo_int().get();
		int chiusure=i.getChiusure().get();
		float prezzo=i.getPrezzo().get();
		float costo=i.getCosto().get();
		String note=i.getNote().get();
		Boolean attivo=cr.getAttivo().get();
		Date datainiz=Date.valueOf(vecchioi.getData().get());
		String clienteiniz=vecchioi.getCliente().get();
		String reginiz=vecchioi.getRegistratore().get();
		String tipoiniz=vecchioi.getTipo_int().get();
		int chiusureiniz=vecchioi.getChiusure().get();
		Date dataUltimo=Date.valueOf(cr.getUltimoInt().get());
		
	
		 
	String query="UPDATE interventi SET data=?,cliente=?,registratore=?,tipo_int=?,chiusure=?,prezzo=?,costo=?,note=? WHERE data=?  AND cliente=? AND registratore=? AND tipo_int=? AND chiusure=?;";
   
	String query2="UPDATE clienti_reg SET ultimo_int=?, attivo=? WHERE client=? AND registr=?;";
 
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setDate(1, data);
	 statement.setString(2, cliente);
	 statement.setString(3, reg);
	 statement.setString(4, tipo);
	 statement.setInt(5, chiusure);
	 statement.setFloat(6, prezzo);
	 statement.setFloat(7, costo);
	 statement.setString(8, note);
	 statement.setDate(9, datainiz);
	 statement.setString(10, clienteiniz);
	 statement.setString(11, reginiz);
	 statement.setString(12, tipoiniz);
	 statement.setInt(13, chiusureiniz);
	 
	 PreparedStatement statement2=conn.prepareStatement(query2);
	 statement2.setDate(1, dataUltimo);
	 statement2.setBoolean(2, attivo);
	 statement2.setString(3, clienteiniz);
	 statement2.setString(4, reginiz);
	 statement.executeUpdate();
	 statement2.executeUpdate();

		statement.close();
		statement2.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Intervento gi� presente nel database!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
	}

		
}


public void aggiornaDopoElimInt(ClientiReg cr){
	
	try{
		Boolean attivo=cr.getAttivo().get();
		Date dataUltimo=Date.valueOf(cr.getUltimoInt().get());
		String cliente=cr.getClient().get();
		String reg=cr.getRegistr().get();
	
	String query="UPDATE clienti_reg SET ultimo_int=?, attivo=? WHERE client=? AND registr=?;";
 
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	statement.setDate(1, dataUltimo);
	statement.setBoolean(2, attivo);
	statement.setString(3, cliente);
	statement.setString(4, reg);
	 statement.executeUpdate();
		statement.close();
		
		conn.close();
		
	}
	catch(Exception e){
		  e.printStackTrace();
	}

		
}

public void modificaIntervento2(Interventi i, ClientiReg cr,Interventi vecchioi){
	
	try{
		Date data=Date.valueOf(i.getData().get());
		String cliente=i.getCliente().get();
		String reg=i.getRegistratore().get();
		String tipo=i.getTipo_int().get();
		int chiusure=i.getChiusure().get();
		float prezzo=i.getPrezzo().get();
		float costo=i.getCosto().get();
		String note=i.getNote().get();
		Boolean attivo=cr.getAttivo().get();
		Date datainiz=Date.valueOf(vecchioi.getData().get());
		String clienteiniz=vecchioi.getCliente().get();
		String reginiz=vecchioi.getRegistratore().get();
		String tipoiniz=vecchioi.getTipo_int().get();
		int chiusureiniz=vecchioi.getChiusure().get();
		
	
		 
	String query="UPDATE interventi SET data=?,cliente=?,registratore=?,tipo_int=?,chiusure=?,prezzo=?,costo=?,note=? WHERE data=?  AND cliente=? AND registratore=? AND tipo_int=? AND chiusure=?;";
   
 
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setDate(1, data);
	 statement.setString(2, cliente);
	 statement.setString(3, reg);
	 statement.setString(4, tipo);
	 statement.setInt(5, chiusure);
	 statement.setFloat(6, prezzo);
	 statement.setFloat(7, costo);
	 statement.setString(8, note);
	 statement.setDate(9, datainiz);
	 statement.setString(10, clienteiniz);
	 statement.setString(11, reginiz);
	 statement.setString(12, tipoiniz);
	 statement.setInt(13, chiusureiniz);
	 statement.executeUpdate();

		statement.close();
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE CHIAVE DUPLICATA
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Chiave duplicata");
       alert.setContentText("Intervento gi� presente nel database!");

       alert.showAndWait();
	     
	   }
	catch(Exception e){
		  Alert alert = new Alert(AlertType.ERROR);  
       alert.setTitle("Dati non validi");
       alert.setContentText("Dati inseriti non validi.");

       alert.showAndWait();
	}

		
}

	
	public List<Tipi_interventi> elencoTipi(){
		List<Tipi_interventi>t=new LinkedList<Tipi_interventi>();
		try{
		String query="select * from tipi_interventi;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 while(res.next()){
			 Tipi_interventi c=new Tipi_interventi(res.getString("tipo"));
			 t.add(c);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return t;
			
	}
	
	
	public List<Registratori> elencoReg(){
		List<Registratori>reg=new LinkedList<Registratori>();
		try{
		String query="select * from registratori;";
		 Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 ResultSet res=statement.executeQuery();
		 
		 while(res.next()){
			 Registratori r=new Registratori(res.getString("matricola"),res.getString("model_rg"));
			 reg.add(r);
			 
		}
		 
		 
		 res.close();
			statement.close();
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return reg;
			
	}
	
public void eliminaCliente(Clienti c){
		
		try{
			String piva=c.getP_iva();
		
		String query="DELETE FROM clienti WHERE p_iva=?;";
       
		Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setString(1, piva);
		 statement.executeUpdate();
		
			statement.close();
		
			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
			
	}
	
public void eliminaModello(Modelli m){
	
	try{
		String mod=m.getModello();
		String marchio=m.getMarchio();
	
	String query="DELETE FROM modelli WHERE modello=? AND marchio=?;";
   
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setString(1, mod);
	 statement.setString(2, marchio);
	 statement.executeUpdate();
	
		statement.close();
	
		conn.close();
		
	}catch(MySQLIntegrityConstraintViolationException ex){
	       //MESSAGGIO DI ERRORE TABELLE ASSOCIATE
		  Alert alert = new Alert(AlertType.ERROR);  
    alert.setTitle("Eliminazione non consentita");
    alert.setContentText("Il modello appartiene a uno o pi� registratori. Eliminazione non consentita.");

    alert.showAndWait();
	     
	   }
	catch(Exception e){
		  e.printStackTrace();
	}

		
}


public void eliminaIntervento(Interventi i){
	
	try{
		String cliente=i.getCliente().get();
		String reg=i.getRegistratore().get();
		Date data=Date.valueOf(i.getData().get());
		int chiusure=i.getChiusure().get();
	
	String query="DELETE FROM interventi WHERE cliente=? AND registratore=? AND data=? AND chiusure=?;";
   
	Connection conn= DBConnect.getConnection();
	 
	 PreparedStatement statement=conn.prepareStatement(query);
	 statement.setString(1, cliente);
	 statement.setString(2, reg);
	 statement.setDate(3, data);
	 statement.setInt(4, chiusure);
	 statement.executeUpdate();
	
		statement.close();
	
		conn.close();
		
	}catch(Exception e){
		e.printStackTrace();
	}
}

	public void eliminaRegistratore(ClientiReg cr){
		
		try{
			String cliente=cr.getClient().get();
			String reg=cr.getRegistr().get();
		
		String query="DELETE FROM clienti_reg WHERE client=? AND registr=?;";
	   
		Connection conn= DBConnect.getConnection();
		 
		 PreparedStatement statement=conn.prepareStatement(query);
		 statement.setString(1, cliente);
		 statement.setString(2, reg);
		 statement.executeUpdate();
		
			statement.close();
		
			conn.close();
			
		}catch(MySQLIntegrityConstraintViolationException ex){
		       //MESSAGGIO DI ERRORE TABELLE ASSOCIATE
			  Alert alert = new Alert(AlertType.ERROR);  
	       alert.setTitle("Eliminazione non consentita");
	       alert.setContentText("Il registratore � oggetto di uno o pi� interventi. Eliminazione non consentita.");

	       alert.showAndWait();
		     
		   }
		catch(Exception e){
			  e.printStackTrace();
		}

		
}

	
	
}
