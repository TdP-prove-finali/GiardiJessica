/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.Registratori;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class FinestraIntController {
	
	 private Model model;
	 private Main main;
	 private Stage dialogStage;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BntNuovoReg;

    @FXML
    private TableColumn<ClientiReg, String> ViaColonna;

    @FXML
    private ComboBox<String> ComboClienti;

    @FXML
    private TableColumn<ClientiReg, String> MatricolaColonna;

    @FXML
    private TableColumn<ClientiReg, String> CapColonna;

    @FXML
    private TableView<ClientiReg> RegTable;

    @FXML
    private TableColumn<ClientiReg, String> CittaColonna;
    
    @FXML
    private TableColumn<ClientiReg, Boolean> StatoColonna;
    
    @FXML
    private TableColumn<ClientiReg, String> ProvColonna;

    @FXML
    private Button BntNuovoInt;

    @FXML
    private Button BntListaInt;
    
    @FXML
    private Button bntmodifica;
    
    @FXML
    private Button cmdelimina;
    

    public void setMain(Main main) {
        this.main = main;
        ObservableList<String> c = FXCollections.observableArrayList(model.elenconomicl());
       
        ComboClienti.setItems(c);
     


    }
    
   
    
    public void setModel(Model model){
  	   this.model=model;
     }
    
    @FXML
    void apriElencoInterventi(ActionEvent event) {

    	main.MostraElencoInterventi();
    }
    
    @FXML
    public void mostraRegDelCliente(){
    
    	String denominazione=ComboClienti.getValue();
    	if(denominazione!=null){
    	
    		ObservableList<ClientiReg> cr = FXCollections.observableArrayList(model.regDelCliente(denominazione));
    		RegTable.setItems(cr);
    	
    	
    	}
    	else{
    		

    	}
    }
    
    @FXML
    void apriNuovoInt(ActionEvent event) {
    	
    	if(RegTable.getSelectionModel().getSelectedItem()==null){
    		 Alert alert = new Alert(AlertType.WARNING);
             alert.initOwner(dialogStage);
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un registratore di cassa.");

             alert.showAndWait();
    	}
    	else{
    	ClientiReg cr=RegTable.getSelectionModel().getSelectedItem();
    	main.MostraNuovoIntervento(cr);
    	String denominazione=ComboClienti.getValue();
    	if(denominazione!=null){
    	
    		ObservableList<ClientiReg> crlist = FXCollections.observableArrayList(model.regDelCliente(denominazione));
    		RegTable.setItems(crlist);
    	}
    	}
    }
    
    
    @FXML
    void apriNuovoReg(ActionEvent event) {
    	
    	if(ComboClienti.getSelectionModel().getSelectedItem()==null){
    		 Alert alert = new Alert(AlertType.WARNING);
             alert.initOwner(dialogStage);
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un cliente.");

             alert.showAndWait();
    	}
    	else{
    	String c=ComboClienti.getSelectionModel().getSelectedItem();
    	Clienti cl=null;
    	for(int k=0;k<model.elencocl().size();k++){
    		if(model.elencocl().get(k).getDenominazione().equals(c)){
    			cl=model.elencocl().get(k);
    		}
    	}
    	Registratori nuovor=new Registratori(null, null);
    	ClientiReg cr=RegTable.getSelectionModel().getSelectedItem();
    	main.MostraNuovoRegistratore(cl,nuovor,cr);
    	 String denominazione=ComboClienti.getValue();
         if(denominazione!=null){
 	    	
	    		ObservableList<ClientiReg> creg = FXCollections.observableArrayList(model.regDelCliente(denominazione));
	    		RegTable.setItems(creg);
	    	}

    	}
    }
    
    @FXML
    public void apriModificaReg(){
    	if(ComboClienti.getSelectionModel().getSelectedItem()==null){
   		 Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(dialogStage);
            alert.setTitle("Elemento non selezionato");
            alert.setContentText("Selezionare un cliente.");

            alert.showAndWait();
   	}
   	else{
   		if(RegTable.getSelectionModel().getSelectedItem() !=null){
   	String c=ComboClienti.getSelectionModel().getSelectedItem();
   	Clienti cl=null;
   	for(int k=0;k<model.elencocl().size();k++){
   		if(model.elencocl().get(k).getDenominazione().equals(c)){
   			cl=model.elencocl().get(k);
   		}
   	}
   	
    	 ClientiReg reg= RegTable.getSelectionModel().getSelectedItem();
    	 Registratori r=null;
    	 for(int k=0;k<model.elencoreg().size();k++){
    
    		 if(model.elencoreg().get(k).getMatricola().toString().equals(reg.getRegistr().get())){
    			 r=model.elencoreg().get(k);
    		 }
    	 }
      
             main.MostraNuovoRegistratore(cl, r,reg);
             String denominazione=ComboClienti.getValue();
             if(denominazione!=null){
     	    	
 	    		ObservableList<ClientiReg> cr = FXCollections.observableArrayList(model.regDelCliente(denominazione));
 	    		RegTable.setItems(cr);
 	    	}

         
   	}else {
             Alert alert = new Alert(AlertType.WARNING);
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un registratore.");

             alert.showAndWait();
         }
   	}
    }
    
    @FXML
    void eliminaReg(ActionEvent event) {
    	if(ComboClienti.getSelectionModel().getSelectedItem()==null){
      		 Alert alert = new Alert(AlertType.WARNING);
               alert.initOwner(dialogStage);
               alert.setTitle("Elemento non selezionato");
               alert.setContentText("Selezionare un cliente.");

               alert.showAndWait();
      	}
    	else{
    		if(RegTable.getSelectionModel().getSelectedItem()!=null){
    	        ClientiReg reg= RegTable.getSelectionModel().getSelectedItem();
    	        model.eliminaReg(reg);
    	        String denominazione=ComboClienti.getValue();
    	    	if(denominazione!=null){
    	    	
    	    		ObservableList<ClientiReg> cr = FXCollections.observableArrayList(model.regDelCliente(denominazione));
    	    		RegTable.setItems(cr);
    	    	}
    		}
    		else{
                Alert alert = new Alert(AlertType.WARNING);   
                alert.setTitle("Elemento non selezionato");
                alert.setContentText("Selezionare un registratore.");

                alert.showAndWait();
    		}
    	}
    }

    @FXML
    void initialize() {
        assert BntNuovoReg != null : "fx:id=\"BntNuovoReg\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert CapColonna != null : "fx:id=\"CapColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert ComboClienti != null : "fx:id=\"ComboClienti\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert MatricolaColonna != null : "fx:id=\"MatricolaColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert CittaColonna != null : "fx:id=\"CittaColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert RegTable != null : "fx:id=\"RegTable\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert ViaColonna != null : "fx:id=\"ViaColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert BntNuovoInt != null : "fx:id=\"BntNuovoInt\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert BntListaInt != null : "fx:id=\"BntListaInt\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert StatoColonna != null : "fx:id=\"StatoColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert ProvColonna != null : "fx:id=\"ProvColonna\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert bntmodifica != null : "fx:id=\"bntmodifica\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        assert cmdelimina != null : "fx:id=\"cmdelimina\" was not injected: check your FXML file 'FinestraInt.fxml'.";
        MatricolaColonna.setCellValueFactory(cellData -> cellData.getValue().registrProperty());
        ViaColonna.setCellValueFactory(cellData -> cellData.getValue().viaRegProperty());
        CapColonna.setCellValueFactory(cellData -> cellData.getValue().capRegProperty());
        CittaColonna.setCellValueFactory(cellData -> cellData.getValue().cittaRegProperty());
        ProvColonna.setCellValueFactory(cellData -> cellData.getValue().provinciaRegProperty());
        StatoColonna.setCellValueFactory(cellData -> cellData.getValue().getAttivo());
        
      
        
    }
}

