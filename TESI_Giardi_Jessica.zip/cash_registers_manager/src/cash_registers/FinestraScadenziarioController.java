/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.time.LocalDate;
import java.time.Month;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiConverter;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.RegistratoreConverter;
import cash_register_model.Registratori;
import cash_register_model.TipiConverter;
import cash_register_model.Tipi_interventi;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class FinestraScadenziarioController {
	
	private Stage dialogStage;
	private Model model;
	private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> ChoiceMesi;

    @FXML
    private TableColumn<ClientiReg, String> ViaColonna;

    @FXML
    private TableView<ClientiReg> TabellaReg;

    @FXML
    private TableColumn<ClientiReg, String> ClienteColonna;

    @FXML
    private TableColumn<ClientiReg, String> CapColonna;

    @FXML
    private TableColumn<ClientiReg, String> ProvColonna;

    @FXML
    private TableColumn<ClientiReg, String> RegistratoreColonna;

    @FXML
    private TableColumn<ClientiReg, String> CittaColonna;
    
    @FXML
    private TableColumn<ClientiReg, LocalDate> ColonnaUltimoInt;

    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<String> c = FXCollections.observableArrayList("Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre");
     	ChoiceMesi.setItems(c);
    }
    
   
    public void setModel(Model model){
  	   this.model=model;
  	
     }
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    @FXML
    public void mostraScad(){
    
    	String mese=ChoiceMesi.getValue();
    	if(mese!=null){
    		int m=0;
    		if(mese.equals("Gennaio")){
    			m=1;
    		}
    		else if(mese.equals("Febbraio")){
    			m=2;
    		}
    		else if(mese.equals("Marzo")){
    			m=3;
    		}
    		else if(mese.equals("Aprile")){
    			m=4;
    		}
    		else if(mese.equals("Maggio")){
    			m=5;
    		}
    		else if(mese.equals("Giugno")){
    			m=6;
    		}
    		else if(mese.equals("Luglio")){
    			m=7;
    		}
    		else if(mese.equals("Agosto")){
    			m=8;
    		}
    		else if(mese.equals("Settembre")){
    			m=9;
    		}
    		else if(mese.equals("Ottobre")){
    			m=10;
    		}
    		else if(mese.equals("Novembre")){
    			m=11;
    		}
    		else if(mese.equals("Dicembre")){
    			m=12;
    		}
    		
    		ObservableList<ClientiReg> cr = FXCollections.observableArrayList(model.elencoScadenze(m));
    		TabellaReg.setItems(cr);
    	
    	
    	}
    	else{
    		

    	}
    }
    
   

    @FXML
    void initialize() {
        assert ChoiceMesi != null : "fx:id=\"ChoiceMesi\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert ViaColonna != null : "fx:id=\"ViaColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert TabellaReg != null : "fx:id=\"TabellaReg\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert ClienteColonna != null : "fx:id=\"ClienteColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert CapColonna != null : "fx:id=\"CapColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert ProvColonna != null : "fx:id=\"ProvColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert RegistratoreColonna != null : "fx:id=\"RegistratoreColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert CittaColonna != null : "fx:id=\"CittaColonna\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        assert ColonnaUltimoInt != null : "fx:id=\"ColonnaUltimoInt\" was not injected: check your FXML file 'FinestraScadenziario.fxml'.";
        
        ClienteColonna.setCellValueFactory(cellData -> cellData.getValue().clientProperty());
        ViaColonna.setCellValueFactory(cellData -> cellData.getValue().viaRegProperty());
        CapColonna.setCellValueFactory(cellData -> cellData.getValue().capRegProperty());
        CittaColonna.setCellValueFactory(cellData -> cellData.getValue().cittaRegProperty());
        ProvColonna.setCellValueFactory(cellData -> cellData.getValue().provinciaRegProperty());
        RegistratoreColonna.setCellValueFactory(cellData -> cellData.getValue().registrProperty());
        ColonnaUltimoInt.setCellValueFactory(cellData -> cellData.getValue().getUltimoInt());
    }
}

