/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.Model;
import cash_register_model.Modelli;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class FinestraModelliController {
	
	 private Model model;
	 private Main main;
	 private Stage dialogStage;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Modelli, String> ColonnaModello;

    @FXML
    private Button cmdmodifica;
    
    @FXML
    private TableView<Modelli> tabellaModelli;

    @FXML
    private Button cmdaggiungi;

    @FXML
    private TableColumn<Modelli, String> ColonnaLogo;

    @FXML
    private TableColumn<Modelli, String> ColonnaMarchio;
    
    @FXML
    private Button cmdelimina;

    
    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<Modelli> m = FXCollections.observableArrayList(model.elencomod());
        tabellaModelli.setItems(m);
    }
    
    public void setModel(Model model){
   	   this.model=model;
      }
    
    @FXML
    private void modifModello() {
        Modelli m=tabellaModelli.getSelectionModel().getSelectedItem();
        if(m==null){
        	 Alert alert = new Alert(AlertType.ERROR);
        
             alert.initOwner(dialogStage);
            
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un modello da modificare!");

             alert.showAndWait();
        }
        else{
        boolean okClicked = main.MostraModelliDaMod(m);
        if (okClicked) {
            model.elencomod();
        }
        }
    }
    
    
    @FXML
    private void aggiungiNuovoModello() {
        Modelli tempMod= new Modelli(null, null, null);
        boolean okClicked = main.MostraModelliDaMod(tempMod);
        if (okClicked) {
            model.elencomod();
        }
        ObservableList<Modelli> m = FXCollections.observableArrayList(model.elencomod());
        tabellaModelli.setItems(m);
    }
    

    @FXML
    void eliminaMod() {
    	 Modelli m=tabellaModelli.getSelectionModel().getSelectedItem();
         if(m==null){
         	 Alert alert = new Alert(AlertType.ERROR);
              alert.initOwner(dialogStage);
              alert.setTitle("Elemento non selezionato");
              alert.setContentText("Selezionare un modello!");
              alert.showAndWait();
         }
         else{
        	
        	model.elimModello(m);
        	 ObservableList<Modelli> md = FXCollections.observableArrayList(model.elencomod());
             tabellaModelli.setItems(md);
        
        }

    }
    
    @FXML
    void initialize() {
    	 assert tabellaModelli != null : "fx:id=\"tabellaModelli\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert ColonnaModello != null : "fx:id=\"ColonnaModello\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert cmdmodifica != null : "fx:id=\"cmdmodifica\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert cmdaggiungi != null : "fx:id=\"cmdaggiungi\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert ColonnaLogo != null : "fx:id=\"ColonnaLogo\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert ColonnaMarchio != null : "fx:id=\"ColonnaMarchio\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        assert cmdelimina != null : "fx:id=\"cmdelimina\" was not injected: check your FXML file 'FinestraModelli.fxml'.";
        ColonnaMarchio.setCellValueFactory(cellData -> cellData.getValue().marchioProperty());
        ColonnaModello.setCellValueFactory(cellData -> cellData.getValue().modelloProperty());
        ColonnaLogo.setCellValueFactory(cellData -> cellData.getValue().logoTipoProperty());
    }
}

