/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiConverter;
import cash_register_model.Model;
import cash_register_model.Modelli;
import cash_register_model.RegistratoreConverter;
import cash_register_model.Registratori;
import cash_register_model.TipiConverter;
import cash_register_model.Tipi_interventi;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class NuovoModifModelloController {
	
	private Stage dialogStage;
	private boolean okClicked = false;
	private Modelli modello;
	private Model model;
	private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button cmdcancella;

    @FXML
    private Button cmdconferma;

    @FXML
    private TextField txtlogo;

    @FXML
    private TextField txtmodello;

    @FXML
    private TextField txtmarchio;
    
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    public boolean isOkClicked() {
        return okClicked;
    }
    
    public void setMain(Main main) {
        this.main = main;
        


     	


    }
    
    
    public void setModello(Modelli modello) {
        this.modello = modello;
        
        txtmarchio.setText(modello.getMarchio());
        txtmodello.setText(modello.getModello());
        txtlogo.setText(modello.getLogo_tipo());

    }
    
    @FXML
    private void confermaModello() {
    	if(modello.getModello()==null){
        if (isInputValid()) {
            modello.setMarchio(txtmarchio.getText());
            modello.setModello(txtmodello.getText());
            modello.setLogo_tipo(txtlogo.getText());
            model.aggiungiMod(modello);
            okClicked = true;
            dialogStage.close();
        }
    	}
    	else{
    		if(isInputValid()){
    			Modelli m=new Modelli(null, null, null);
    			m.setModello(modello.getModello());
    			m.setMarchio(modello.getMarchio());
    			m.setLogo_tipo(modello.getLogo_tipo());
    			modello.setLogo_tipo(txtlogo.getText());
    			modello.setMarchio(txtmarchio.getText());
    			modello.setModello(txtmodello.getText());
    			
    			model.modificaMod(modello, m);
    			okClicked = true;
    	        dialogStage.close();
    		}
    	}
        }
    
    private boolean isInputValid() {
        String errorMessage = "";

        if (txtmarchio.getText() == null || txtmarchio.getText().length() == 0) {
            errorMessage += "Inserire il marchio!\n"; 
        }
        if (txtmodello.getText() == null || txtmodello.getText().length() == 0) {
            errorMessage += "Inserire il modello!\n"; 
        }
        if (txtlogo.getText() == null || txtlogo.getText().length() == 0) {
            errorMessage += "Inserire il logo tipo fiscale!\n"; 
        }
        else{
        	String logo=txtlogo.getText();
        	if(logo.length()!=2)
        		 errorMessage += "Logo tipo fiscale non valido.\n"; 
        	String cf2 = logo.toUpperCase();
             for(int i=0; i<2; i++ ){
             char c = cf2.charAt(i);
             if( ! ( c>='0' && c<='9' || c>='A' && c<='Z' ) )
             	errorMessage +="Logo tipo fiscale non valido.\n";
         }
        }
       
       
        
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }

    }
    
    public void setModel(Model model){
    	   this.model=model;
       }

    @FXML
    void initialize() {
        assert cmdcancella != null : "fx:id=\"cmdcancella\" was not injected: check your FXML file 'NuovoModifModello.fxml'.";
        assert cmdconferma != null : "fx:id=\"cmdconferma\" was not injected: check your FXML file 'NuovoModifModello.fxml'.";
        assert txtlogo != null : "fx:id=\"txtlogo\" was not injected: check your FXML file 'NuovoModifModello.fxml'.";
        assert txtmodello != null : "fx:id=\"txtmodello\" was not injected: check your FXML file 'NuovoModifModello.fxml'.";
        assert txtmarchio != null : "fx:id=\"txtmarchio\" was not injected: check your FXML file 'NuovoModifModello.fxml'.";

    }
}

