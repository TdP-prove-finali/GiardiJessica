/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class RegistersController {
	 private boolean okClicked = false;
	 private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button cmdregistratori;

    @FXML
    private Button cmdmodelli;

    @FXML
    private Button cmdclienti;
    
    @FXML
    private Button cmdinterventi;
    
    @FXML
    private Button cmdScadenziario;
    
    @FXML
    private Button cmdIntTrim;
    
    @FXML
    private Button CmdOttimizzazione;
    
    @FXML
    private ImageView logo;
    
    @FXML
    private ImageView scritta;
    
    public void setMain(Main main) {
        this.main = main;
        FileInputStream file;
		try {
			file = new FileInputStream("src/resources/logo.jpg");
			Image image = new Image(file);
	        logo.setImage(image);
	        
	        file = new FileInputStream("src/resources/scritta.jpg");
			Image image2 = new Image(file);
	        scritta.setImage(image2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }


    @FXML
    void apriRegistratori(ActionEvent event) {

    }

    @FXML
    void apriModelli(ActionEvent event) {

    	main.MostraModelli();
    }
    
    public boolean isOkClicked() {
        return okClicked;
    }
    
    @FXML
    private void handleNewPerson() {
        //Person tempPerson = new Person();
        main.showPersonEditDialog();
        if (okClicked) {
            //mainApp.getPersonData().add(tempPerson);
        }
    }
    
    @FXML
    void apriInterventi(ActionEvent event) {

    	main.MostraInterventi();
    }
    
    @FXML
    void apriScadenziario(ActionEvent event) {

    	main.MostraScadenziario();
    }

    @FXML
    void apriIntervTrim(ActionEvent event) {

    	main.MostraIntervTrim();
    }
    
    @FXML
    void apriRegInEsaurimento(ActionEvent event) {

    	main.MostraRegEsaurimento();
    }
    
    @FXML
    void apriOttimizz(ActionEvent event) {

    	main.MostraOttimizz();
    }
    
    
    @FXML
    void initialize() {
    	assert cmdinterventi != null : "fx:id=\"cmdinterventi\" was not injected: check your FXML file 'register.fxml'.";
        assert cmdregistratori != null : "fx:id=\"cmdregistratori\" was not injected: check your FXML file 'register.fxml'.";
        assert cmdmodelli != null : "fx:id=\"cmdmodelli\" was not injected: check your FXML file 'register.fxml'.";
        assert cmdclienti != null : "fx:id=\"cmdclienti\" was not injected: check your FXML file 'register.fxml'.";
        assert cmdScadenziario != null : "fx:id=\"cmdScadenziario\" was not injected: check your FXML file 'register.fxml'.";
        assert cmdIntTrim != null : "fx:id=\"cmdIntTrim\" was not injected: check your FXML file 'register.fxml'.";
        assert CmdOttimizzazione != null : "fx:id=\"CmdOttimizzazione\" was not injected: check your FXML file 'register.fxml'.";
        assert scritta != null : "fx:id=\"scritta\" was not injected: check your FXML file 'register.fxml'.";
        assert logo != null : "fx:id=\"logo\" was not injected: check your FXML file 'register.fxml'.";
    }
}
