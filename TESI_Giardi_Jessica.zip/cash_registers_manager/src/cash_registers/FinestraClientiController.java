/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.Registratori;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeView;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Callback;

public class FinestraClientiController {
	
     private Model model;
	 private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button cmdmodifica;

    @FXML
    private Button cmdaggiungi;

    @FXML
    private Button cmdelimina;
    
    @FXML
    private TableColumn<Clienti, String> colonnaDenominaz;
    
    @FXML
    private TableView<Clienti> tabella;
    
    @FXML
    private Label denominazLabel;

    @FXML
    private Label provinciaLabel;

    @FXML
    private Label codfiscLabel;
    @FXML
    private Label viaLabel;

    @FXML
    private Label pivaLabel;

    @FXML
    private Label capLabel;

    @FXML
    private Label cittaLabel;

  

  
    public void setMain(Main main) {
        this.main = main;
        ObservableList<Clienti> c = FXCollections.observableArrayList(model.elencocl());
        tabella.setItems(c);
     


    }
    
    public void setModel(Model model){
  	   this.model=model;
     }

    
    private void mostraDettagliCliente(Clienti cliente) {
        if (cliente != null) {
      
            denominazLabel.setText(cliente.getDenominazione());
            viaLabel.setText(cliente.getVia_sede());
            cittaLabel.setText(cliente.getCitta_sede());
            capLabel.setText(cliente.getCap_sede());
            provinciaLabel.setText(cliente.getProvincia_sede());
            codfiscLabel.setText(cliente.getCod_fisc());
            pivaLabel.setText(cliente.getP_iva());

        } else {
          
            denominazLabel.setText("");
            viaLabel.setText("");
            cittaLabel.setText("");
            capLabel.setText("");
            provinciaLabel.setText("");
            codfiscLabel.setText("");
            pivaLabel.setText("");
        }
    }
    
   
       
    @FXML
    private void aggiungiNuovoCliente() {
        Clienti tempCl= new Clienti(null, null, null, null, null, null, null);
        boolean okClicked = main.MostraClientDaMod(tempCl);
        if (okClicked) {
            model.elencocl().add(tempCl);
        }
        ObservableList<Clienti> c = FXCollections.observableArrayList(model.elencocl());
        tabella.setItems(c);
    }
	
    @FXML
    private void modificaCliente() {
    	 Clienti c = tabella.getSelectionModel().getSelectedItem();
    	 if (c != null) {
             boolean okClicked = main.MostraClientDaMod(c);
             ObservableList<Clienti> cl = FXCollections.observableArrayList(model.elencocl());
             tabella.setItems(cl);

         } else {
   
             Alert alert = new Alert(AlertType.WARNING);
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un cliente.");

             alert.showAndWait();
         }
     
       
    }
		
    @FXML	
    public void elimina(){
    	 Clienti c = tabella.getSelectionModel().getSelectedItem();
    	
    	 if (c != null) {
    		 List<ClientiReg>cr=new ArrayList<ClientiReg>(model.regDelCliente(c.getDenominazione()));
    		 if(cr.size()>0){
    		
                 Alert alert = new Alert(AlertType.ERROR);
                 alert.setTitle("Eliminazione non consentita");
                 alert.setContentText("Il cliente � associato a uno o pi� registratore di cassa. Non � possibile effettuare l'eliminazione.");

                 alert.showAndWait();
    		 }
    		 else{
             model.elimCliente(c);
             ObservableList<Clienti> cl = FXCollections.observableArrayList(model.elencocl());
             tabella.setItems(cl);
    		 }
            

         } 
    	 else{
             
             Alert alert = new Alert(AlertType.WARNING);
             alert.setTitle("Elemento non selezionato");
             alert.setContentText("Selezionare un cliente.");

             alert.showAndWait();
         }
    }
    
   

    @FXML
    void initialize() {
    	
    	
        assert colonnaDenominaz != null : "fx:id=\"colonnaDenominaz\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert cmdmodifica != null : "fx:id=\"cmdmodifica\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert cmdaggiungi != null : "fx:id=\"cmdaggiungi\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert tabella != null : "fx:id=\"tabella\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert cmdelimina != null : "fx:id=\"cmdelimina\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert viaLabel != null : "fx:id=\"viaLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert pivaLabel != null : "fx:id=\"pivaLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert capLabel != null : "fx:id=\"capLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert cittaLabel != null : "fx:id=\"cittaLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert denominazLabel != null : "fx:id=\"denominazLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert provinciaLabel != null : "fx:id=\"provinciaLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert codfiscLabel != null : "fx:id=\"codfiscLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
        assert codfiscLabel != null : "fx:id=\"codfiscLabel\" was not injected: check your FXML file 'FinestraClienti.fxml'.";
    
        colonnaDenominaz.setCellValueFactory(cellData -> cellData.getValue().denominazProperty());
        mostraDettagliCliente(null);
        tabella.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> mostraDettagliCliente(newValue));
        
        
        
       
        
        
    }
}

