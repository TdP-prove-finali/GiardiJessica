/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiConverter;
import cash_register_model.ClientiReg;
import cash_register_model.ClientiRegConverter;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.RegistratoreConverter;
import cash_register_model.Registratori;
import cash_register_model.TipiConverter;
import cash_register_model.Tipi_interventi;
import cash_registers_db.RegisterDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import util.DateUtil;

public class FinestraModificaIntController {
	private Stage dialogStage;
	private Interventi i;
	private Model model;

	private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BntModifica;

    @FXML
    private TextField TxtPrezzo;

    @FXML
    private TextField TxtChiusure;

    @FXML
    private Label lblcliente;

    @FXML
    private Label lblreg;

    @FXML
    private Button BntConferma;

    @FXML
    private TextField TxtCosto;


    @FXML
    private TextField TxtData;

    @FXML
    private ChoiceBox<Tipi_interventi> ChoiseTipo;

    @FXML
    private TextArea TxtArea;
    
    
    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<Tipi_interventi> t = FXCollections.observableArrayList(model.elencotipi());
        ChoiseTipo.setItems(t);
        ChoiseTipo.setConverter(new TipiConverter());
       
    }
    
   
    
    public void setModel(Model model){
  	   this.model=model;
  	
     }
    
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
   
    
    public void setIntervento(Interventi i) {
        this.i = i;
        
        TxtData.setText(DateUtil.format(i.getData().get()));
        TxtData.setPromptText("dd.mm.yyyy");
        lblcliente.setText(i.getCliente().get());
        lblreg.setText(i.getRegistratore().get());
        TxtChiusure.setText(Integer.toString(i.getChiusure().get()));
       
        int indt=0;
        for(int k=0;k<model.elencotipi().size();k++){
        	if(model.elencotipi().get(k).getTipo().equals(i.getTipo_int().get())){
        		indt=k;
        	}
        }
  
        ChoiseTipo.getSelectionModel().select(model.elencotipi().get(indt));
    
       
        TxtPrezzo.setText(Float.toString(i.getPrezzo().get()));
        TxtCosto.setText(Float.toString(i.getCosto().get()));
    }
   
    @FXML
    public void confermaInt(){
    	if(isInputValid()){
    	String den="";
    	for(int j=0;j<model.elencocl().size();j++){
    		if(model.elencocl().get(j).getP_iva().equals(i.getCliente().get())){
    			den=model.elencocl().get(j).getDenominazione();
    		}
    	}
    	ClientiReg c=null;
    	for(int k=0;k<model.regDelCliente(den).size();k++){
    		if(model.regDelCliente(den).get(k).getRegistr().get().equals(i.getRegistratore().get())){
    			c=model.regDelCliente(den).get(k);	
    		}
    	}
    	Interventi iniz=new Interventi(null, null, null, null, 0, 0, 0, null);
    	iniz.setChiusure(i.getChiusure().get());
    	iniz.setCliente(i.getCliente().get());
    	iniz.setRegistratore(i.getRegistratore().get());
    	iniz.setTipo_int(i.getTipo_int().get());
    	iniz.setData(i.getData().get());
    	
    	i.setChiusure(Integer.parseInt(TxtChiusure.getText()));
    	i.setCliente(lblcliente.getText());
    	i.setCosto(Float.parseFloat(TxtCosto.getText()));
    	i.setData(DateUtil.parse(TxtData.getText()));
    	i.setNote(TxtArea.getText());
    	i.setPrezzo(Float.parseFloat(TxtPrezzo.getText()));
    	i.setRegistratore(lblreg.getText());
    	i.setTipo_int(ChoiseTipo.getSelectionModel().getSelectedItem().getTipo());
  
    	List<Interventi>interventi=new ArrayList<Interventi>(model.intDelCliente(i.getCliente().get(),i.getRegistratore().get()));
		if(interventi.size()>=2){
    	if(interventi.get(0).getData().get().isBefore(i.getData().get())){
    		c.setultimoint(i.getData().get());
    		if(i.getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || i.getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || i.getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
	    		 c.setAttivo(true);
	    	}
	    	else{
	    	     c.setAttivo(false);
	    	}
    		model.modifInt(i, c,iniz);
    		dialogStage.close();
    	}
    	else{
    		if(iniz.getData().get().equals(interventi.get(0).getData().get())){
    	
    			if(interventi.get(1).getData().get().isAfter(i.getData().get())){
    				c.setultimoint(interventi.get(1).getData().get());
    				if(interventi.get(1).getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || interventi.get(1).getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || interventi.get(1).getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
   		    		 c.setAttivo(true);
   		    	}
   		    	else{
   		    	     c.setAttivo(false);
   		    	}
    				
    			}
    			else{
    				c.setultimoint(i.getData().get());
    				if(i.getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || i.getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || i.getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
    		    		 c.setAttivo(true);
    		    	}
    		    	else{
    		    	     c.setAttivo(false);
    		    	}
    			}
    		
    		}
    		else{
    			if(interventi.get(1).getData().get().isAfter(i.getData().get())){
    				c.setultimoint(interventi.get(1).getData().get());
    				if(interventi.get(1).getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || interventi.get(1).getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || interventi.get(1).getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
    		    		 c.setAttivo(true);
    		    	}
    		    	else{
    		    	     c.setAttivo(false);
    		    	}
    			}
    			else{
    				c.setultimoint(i.getData().get());
    			}
    		}
    	
    		model.modifInt(i, c,iniz);
			dialogStage.close();
    	}
    	}else{
    		c.setultimoint(i.getData().get());
			if(i.getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || i.getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || i.getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
	    		 c.setAttivo(true);
	    	}
	    	else{
	    	     c.setAttivo(false);
	    	}
			model.modifInt(i, c,iniz);
			dialogStage.close();
    	}
    	}
    }
    
    
    private boolean isInputValid() {
        String errorMessage = "";

        if (TxtData.getText() == null || TxtData.getText().length() == 0) {
            errorMessage += "Inserire la data!\n"; 
        }
        else{
        if (!DateUtil.validDate(TxtData.getText())) {
            errorMessage += "Inserire la data nel formato dd.mm.yyyy!\n";
        }
        }
        if (TxtChiusure.getText() == null || TxtChiusure.getText().length() == 0) {
            errorMessage += "Inserire il numero di chiusure rilevato!\n"; 
        }
        else{
        	
        	String ch=TxtChiusure.getText();
        	if( ch.length() > 4 )
        		errorMessage +="Numero di chiusure non valido.\n";
        	else{
        		
        		try{
                     int c=Integer.parseInt(ch);
                     
                    
        		}   catch (NumberFormatException e) {
        			errorMessage+="Numero di chiusure non valido.\n";
        		}  
                 
        		 }
        	}
        
        if (TxtPrezzo.getText() == null || TxtPrezzo.getText().length() == 0) {
            errorMessage += "Inserire il prezzo dell'intervento!\n"; 
        }
        else {
        	try{
        		Float p=Float.parseFloat(TxtPrezzo.getText());
        	} catch (NumberFormatException e) {
    			errorMessage+="Prezzo inserito non valido.\n";
    		}

        	}
        		
        if (TxtCosto.getText() == null || TxtCosto.getText().length() == 0) {
            errorMessage += "Inserire il costo sostenuto per l'intervento!\n"; 
        }
         else {
        	try{
        		Float c=Float.parseFloat(TxtCosto.getText());
        	} catch (NumberFormatException e) {
    			errorMessage+="Costo inserito non valido.\n";
    		}

        	}
       
        	try{
        		String c=TxtArea.getText();
        	} catch (Exception e) {
    			errorMessage+="Note inserite non valide.\n";
    		}

        if (ChoiseTipo.getSelectionModel().getSelectedItem()== null) {
            errorMessage += "Selezionare il tipo di intervento!\n"; 
        }
        
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Valori inseriti non corretti");
            alert.setHeaderText("Correggere i valori inseriti.");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }

    }
    

    @FXML
    void initialize() {
        assert BntModifica != null : "fx:id=\"BntModifica\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert TxtPrezzo != null : "fx:id=\"TxtPrezzo\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert TxtChiusure != null : "fx:id=\"TxtChiusure\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert lblcliente != null : "fx:id=\"lblcliente\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert lblreg != null : "fx:id=\"lblreg\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert BntConferma != null : "fx:id=\"BntConferma\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert TxtCosto != null : "fx:id=\"TxtCosto\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert TxtData != null : "fx:id=\"TxtData\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert ChoiseTipo != null : "fx:id=\"ChoiseTipo\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";
        assert TxtArea != null : "fx:id=\"TxtArea\" was not injected: check your FXML file 'FinestraModificaInt.fxml'.";

        
        
    	
    }
}

