/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import util.DateUtil;

public class FinestraRegDaSostituireController {
	
	private Stage dialogStage;
	private Model model;
	private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

   

    @FXML
    private TableView<Interventi> TabReg;

    @FXML
    private Label LlModello;

    @FXML
    private Label LblData;

    @FXML
    private Label LblCliente;

    @FXML
    private Label LblChiusure;

    @FXML
    private TableColumn<Interventi, String> MatricolaColonna;

    @FXML
    private Label LblMarchio;
    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<Interventi> c = FXCollections.observableArrayList(model.regInEsaurimento());
       TabReg.setItems(c);
     	
    }
    
    
    public void setModel(Model model){
  	   this.model=model;
  	
     }
    
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    
    private void mostraDettagliReg(Interventi reg) {
        if (reg != null) {
      
            LblData.setText(DateUtil.format(reg.getData().get()));
            LblChiusure.setText(String.valueOf(reg.getChiusure().get()));
            LblCliente.setText(reg.getCliente().get());
            for(int i=0;i<model.elencoreg().size();i++){
            	for(int j=0;j<model.elencomod().size();j++){
            		if(model.elencoreg().get(i).getModel_rg().equals(model.elencomod().get(j).getModello())){
            			LlModello.setText(model.elencomod().get(j).getModello());
            			LblMarchio.setText(model.elencomod().get(j).getMarchio());
            		}
            	}
            	
            }
           
        } else {
          
            LblData.setText("");
            LblChiusure.setText("");
            LblCliente.setText("");
            LlModello.setText("");
            LblMarchio.setText("");
            
        }
    }
    

    @FXML
    void initialize() {
       
        assert TabReg != null : "fx:id=\"TabReg\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert LlModello != null : "fx:id=\"LlModello\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert LblData != null : "fx:id=\"LblData\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert LblCliente != null : "fx:id=\"LblCliente\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert LblChiusure != null : "fx:id=\"LblChiusure\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert MatricolaColonna != null : "fx:id=\"MatricolaColonna\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
        assert LblMarchio != null : "fx:id=\"LblMarchio\" was not injected: check your FXML file 'FinestraRegDaSostituire.fxml'.";
       
        MatricolaColonna.setCellValueFactory(cellData -> cellData.getValue().getRegistratore());
        mostraDettagliReg(null);
        TabReg.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> mostraDettagliReg(newValue));
        
    }
}

