/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiConverter;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.RegistratoreConverter;
import cash_register_model.Registratori;
import cash_register_model.TipiConverter;
import cash_register_model.Tipi_interventi;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import util.DateUtil;

public class FinestraInterventiTrimestreController {
	private Stage dialogStage;
	private Model model;
	private Main main;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Interventi,String> TipoColonna;

    @FXML
    private TableColumn<Interventi, LocalDate> DataColonna;

    @FXML
    private Button cmdConferma;

    @FXML
    private ChoiceBox<Integer> ChoiceTrimestre;

    @FXML
    private TableColumn<Interventi, String> ClienteColonna;

    @FXML
    private TextField TxtAnno;

    @FXML
    private TableColumn<Interventi, String> RegistratoreColonna;
    
    @FXML
    private TableView<Interventi> tabellaInterv;

    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<Integer> c = FXCollections.observableArrayList(1,2,3,4);
        ChoiceTrimestre.setItems(c);

     	


    }
    
   
    
    public void setModel(Model model){
  	   this.model=model;
  	
     }
    
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    
    @FXML
    public void mostraInt(){
    	if(isInputValid()){
    	List<Interventi>intTabella=new ArrayList<Interventi>();
    	int trim=ChoiceTrimestre.getSelectionModel().getSelectedItem();
    	int anno=Integer.parseInt(TxtAnno.getText());
        for(int i=0;i<model.elencoInterventi().size();i++){
        	LocalDate data=model.elencoInterventi().get(i).getData().get();
        	int mesei=data.getMonthValue();
        	int annoi=data.getYear();
        	if(trim==1){
        		if(1<=mesei & mesei<=3 & annoi==anno){
        			intTabella.add(model.elencoInterventi().get(i));
        		}
        	}
        	if(trim==2){
        		if(4<=mesei & mesei<=6 & annoi==anno){
        			intTabella.add(model.elencoInterventi().get(i));
        		}
        	}
        	if(trim==3){
        		if(7<=mesei & mesei<=9 & annoi==anno){
        			intTabella.add(model.elencoInterventi().get(i));
        		}
        	}
        	if(trim==4){
        		if(10<=mesei & mesei<=12 & annoi==anno){
        			intTabella.add(model.elencoInterventi().get(i));
        		}
        	}
        }
        ObservableList<Interventi> c = FXCollections.observableArrayList(intTabella);
        tabellaInterv.setItems(c);
    	}	
    }
    
    private boolean isInputValid() {
        String errorMessage = "";
        if (ChoiceTrimestre.getSelectionModel().getSelectedItem() == null) {
            errorMessage += "Selezionare un trimestre!\n"; 
        }
        
        if (TxtAnno.getText() == null || TxtAnno.getText().length() == 0) {
            errorMessage += "Inserire l'anno!\n"; 
        }
        else{
        	int anno=0;
        	Boolean f=false;
        	try{
        		 anno=Integer.parseInt(TxtAnno.getText());
        }   catch (NumberFormatException e) {
			errorMessage+="Anno inserito non valido.\n";
			f=true;
        }
        	if(f==false){
            if(!DateUtil.validDate("01.01."+anno)){
        	
        		errorMessage += "Anno inserito non valido.\n"; 
            }
        	}
        	
        }
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Valori inseriti non corretti");
            alert.setHeaderText("Correggere i valori inseriti.");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
        
    }
    
    
    @FXML
    void initialize() {
        assert TipoColonna != null : "fx:id=\"TipoColonna\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert DataColonna != null : "fx:id=\"DataColonna\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert cmdConferma != null : "fx:id=\"cmdConferma\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert ChoiceTrimestre != null : "fx:id=\"ChoiceTrimestre\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert ClienteColonna != null : "fx:id=\"ClienteColonna\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert TxtAnno != null : "fx:id=\"TxtAnno\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert RegistratoreColonna != null : "fx:id=\"RegistratoreColonna\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        assert tabellaInterv != null : "fx:id=\"tabellaInterv\" was not injected: check your FXML file 'FinestraInterventiTrimestre.fxml'.";
        DataColonna.setCellValueFactory(cellData -> cellData.getValue().getData());
        ClienteColonna.setCellValueFactory(cellData -> cellData.getValue().getCliente());
        RegistratoreColonna.setCellValueFactory(cellData -> cellData.getValue().getRegistratore());
        TipoColonna.setCellValueFactory(cellData -> cellData.getValue().getTipo_int());
    }
}
