/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;
	
import java.io.IOException;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import cash_register_model.Modelli;
import cash_register_model.Registratori;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	
	  private Stage primaryStage;
	  private BorderPane rootLayout;
	  private ObservableList<Clienti> clientiData = FXCollections.observableArrayList();
	 
	
	@Override
	public void start(Stage primaryStage) {
		 this.primaryStage = primaryStage;
	        this.primaryStage.setTitle("Cash Registers Manager");
	        this.primaryStage.getIcons().add(new Image("file:image/logo.jpg"));
	        finestraIniziale();
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public void finestraIniziale(){
		  try {
	            // Load root layout from fxml file.
	            FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(Main.class.getResource("Registers.fxml"));
	            rootLayout = (BorderPane) loader.load();
              
	            // Show the scene containing the root layout.
	            Scene scene = new Scene(rootLayout);
	            primaryStage.setScene(scene);

	            // Give the controller access to the main app.
	            RegistersController controller = loader.getController();
	            
	            controller.setMain(this);

	            primaryStage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	}
	
	public void showPersonEditDialog() {
		
	    try {
	    	
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("FinestraClienti.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Clienti");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        FinestraClientiController controller = loader.getController();
	       
	      controller.setModel(model);
	      controller.setMain(this);
	        //controller.setDialogStage(dialogStage);
	        //controller.setPerson(person);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	    } catch (IOException e) {
	        e.printStackTrace();
	       
	    }
	}
	
	public boolean MostraClientDaMod(Clienti cliente) {
	    try {
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("FinestraModifCliente.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Cliente");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        FinestraModifClienteController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	       controller.setModel(model);
	        controller.setCliente(cliente);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        return true;
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	
	
	
	
	public void MostraModelli() {
	    try {
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("FinestraModelli.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Modelli");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        FinestraModelliController controller = loader.getController();
	     //   controller.setDialogStage(dialogStage);
	    
		       
		      controller.setModel(model);
		      controller.setMain(this);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        
	    } catch (IOException e) {
	        e.printStackTrace();
	       
	    }
	}
	
	public boolean MostraModelliDaMod(Modelli modello) {
	    try {
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("NuovoModifModello.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Modello");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        NuovoModifModelloController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        controller.setModel(model);
	        controller.setMain(this);
	        controller.setModello(modello);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        return controller.isOkClicked();
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	
	public void MostraInterventi() {
	    try {
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("FinestraInt.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Interventi");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        FinestraIntController controller = loader.getController();
	     //   controller.setDialogStage(dialogStage);
	    
		       
		      controller.setModel(model);
		      controller.setMain(this);

	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        
	    } catch (IOException e) {
	        e.printStackTrace();
	       
	    }
	}
	
	

	public void MostraElencoInterventi() {
		  try {
		        // Load the fxml file and create a new stage for the popup dialog.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Main.class.getResource("FinestraElencoInt.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();
		        Model model=new Model();
		        // Create the dialog Stage.
		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Elenco interventi");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        // Set the person into the controller.
		        FinestraElencoIntController controller = loader.getController();
		     //   controller.setDialogStage(dialogStage);
		    
			       
			      controller.setModel(model);
			      controller.setMain(this);

		        // Show the dialog and wait until the user closes it
		        dialogStage.showAndWait();

		        
		    } catch (IOException e) {
		        e.printStackTrace();
		       
		    }
		
	}
	
	public boolean MostraIntDaMod(Interventi i) {
	    try {
	        // Load the fxml file and create a new stage for the popup dialog.
	        FXMLLoader loader = new FXMLLoader();
	        loader.setLocation(Main.class.getResource("FinestraModificaInt.fxml"));
	        AnchorPane page = (AnchorPane) loader.load();
	        Model model=new Model();
	        // Create the dialog Stage.
	        Stage dialogStage = new Stage();
	        dialogStage.setTitle("Intervento");
	        dialogStage.initModality(Modality.WINDOW_MODAL);
	        dialogStage.initOwner(primaryStage);
	        Scene scene = new Scene(page);
	        dialogStage.setScene(scene);

	        // Set the person into the controller.
	        FinestraModificaIntController controller = loader.getController();
	        controller.setDialogStage(dialogStage);
	        
	        controller.setModel(model);
		      controller.setMain(this);
		      controller.setIntervento(i);
	        // Show the dialog and wait until the user closes it
	        dialogStage.showAndWait();

	        return true;
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false;
	    }
	}

	public void MostraNuovoIntervento(ClientiReg i) {
		try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("FinestraNuovoIntervento.fxml"));
        AnchorPane page = (AnchorPane) loader.load();
        Model model=new Model();
        // Create the dialog Stage.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Nuovo intervento");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        dialogStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);

        // Set the person into the controller.
        FinestraNuovoInterventoController controller = loader.getController();
        controller.setDialogStage(dialogStage);
    
	       
	      controller.setModel(model);
	      controller.setMain(this);
	      controller.setDatiNuovoInt(i);
        // Show the dialog and wait until the user closes it
        dialogStage.showAndWait();

        
    } catch (IOException e) {
        e.printStackTrace();
       
    }
	
	}
	
	
	public void MostraNuovoRegistratore(Clienti i,Registratori reg,ClientiReg cr) {
		try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("FinestraNuovoRegistratore.fxml"));
        AnchorPane page = (AnchorPane) loader.load();
        Model model=new Model();
        // Create the dialog Stage.
        Stage dialogStage = new Stage();
        dialogStage.setTitle("Nuovo registratore di cassa");
        dialogStage.initModality(Modality.WINDOW_MODAL);
        dialogStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        dialogStage.setScene(scene);

        // Set the person into the controller.
        FinestraNuovoRegistratoreController controller = loader.getController();
        controller.setDialogStage(dialogStage);
    
	       
	      controller.setModel(model);
	      controller.setMain(this);
	      controller.setDatiNuovoReg(i,reg,cr);
        // Show the dialog and wait until the user closes it
        dialogStage.showAndWait();

        
    } catch (IOException e) {
        e.printStackTrace();
       
    }
	
	}
	
	public void MostraScadenziario() {
		  try {
		        // Load the fxml file and create a new stage for the popup dialog.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Main.class.getResource("FinestraScadenziario.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();
		        Model model=new Model();
		        // Create the dialog Stage.
		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Scadenziario verifiche periodiche");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        // Set the person into the controller.
		        FinestraScadenziarioController controller = loader.getController();
		     //   controller.setDialogStage(dialogStage);
		    
			       
			      controller.setModel(model);
			      controller.setMain(this);

		        // Show the dialog and wait until the user closes it
		        dialogStage.showAndWait();

		        
		    } catch (IOException e) {
		        e.printStackTrace();
		       
		    }
		
	}
	
	public void MostraIntervTrim() {
		  try {
		        // Load the fxml file and create a new stage for the popup dialog.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Main.class.getResource("FinestraInterventiTrimestre.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();
		        Model model=new Model();
		        // Create the dialog Stage.
		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Interventi del trimestre");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        // Set the person into the controller.
		        FinestraInterventiTrimestreController controller = loader.getController();
		        controller.setDialogStage(dialogStage);
		    
			       
			      controller.setModel(model);
			      controller.setMain(this);

		        // Show the dialog and wait until the user closes it
		        dialogStage.showAndWait();

		        
		    } catch (IOException e) {
		        e.printStackTrace();
		       
		    }
		
	}
	
	public void MostraRegEsaurimento() {
		  try {
		        // Load the fxml file and create a new stage for the popup dialog.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Main.class.getResource("FinestraRegDaSostituire.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();
		        Model model=new Model();
		        // Create the dialog Stage.
		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Registratori di cassa con memoria in esaurimento");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        // Set the person into the controller.
		        FinestraRegDaSostituireController controller = loader.getController();
		     //   controller.setDialogStage(dialogStage);
		    
			       
			      controller.setModel(model);
			      controller.setMain(this);

		        // Show the dialog and wait until the user closes it
		        dialogStage.showAndWait();

		        
		    } catch (IOException e) {
		        e.printStackTrace();
		       
		    }
		
	}
	
	
	
	public void MostraOttimizz() {
		  try {
		        // Load the fxml file and create a new stage for the popup dialog.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(Main.class.getResource("FinestraOttimizzazione.fxml"));
		        AnchorPane page = (AnchorPane) loader.load();
		        Model model=new Model();
		        // Create the dialog Stage.
		        Stage dialogStage = new Stage();
		        dialogStage.setTitle("Sezione ottimizzazione");
		        dialogStage.initModality(Modality.WINDOW_MODAL);
		        dialogStage.initOwner(primaryStage);
		        Scene scene = new Scene(page);
		        dialogStage.setScene(scene);

		        // Set the person into the controller.
		        FinestraOttimizzazioneController controller = loader.getController();
		     //   controller.setDialogStage(dialogStage);
		    
			       
			      controller.setModel(model);
			      controller.setMain(this);

		        // Show the dialog and wait until the user closes it
		        dialogStage.showAndWait();

		        
		    } catch (IOException e) {
		        e.printStackTrace();
		       
		    }
		
	}
}
