/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Interventi;
import cash_register_model.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import util.DateUtil;

public class FinestraElencoIntController {

	 private Model model;
	 private Main main;
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Interventi, String> TipoColonna;

    @FXML
    private TableColumn<Interventi, LocalDate> DataColonna;

    @FXML
    private TableColumn<Interventi, String> MatrColonna;

    @FXML
    private TableColumn<Interventi, String> ClienteColonna;
    
    @FXML
    private TableView<Interventi> IntTable;

    @FXML
    private Label LblNote;

    @FXML
    private Label LblTipo;

    @FXML
    private Label LblData;

    @FXML
    private Label LblCliente;

    @FXML
    private Label LblCosto;

    @FXML
    private Label LblRegistratore;

    @FXML
    private Button BtnModifica;
    
    @FXML
    private Label LblChiusure;
    
    @FXML
    private Button BntElimina;

    @FXML
    private Label LblPrezzo;


    public void setMain(Main main) {
        this.main = main;
        ObservableList<Interventi> i = FXCollections.observableArrayList(model.elencoInterventi());
        IntTable.setItems(i);

    }
    
    public void setModel(Model model){
  	   this.model=model;
     }
    
    private void mostraDettagliIntervento(Interventi i) {
        if (i != null) {
      
            LblData.setText(DateUtil.format(i.getData().get()));
            LblCliente.setText(i.getCliente().get().toString());
            LblRegistratore.setText(i.getRegistratore().get().toString());
            LblTipo.setText(i.getTipo_int().get());
            LblChiusure.setText(Integer.toString(i.getChiusure().get()));
            LblNote.setText(i.getNote().get());
            LblPrezzo.setText(Float.toString(i.getPrezzo().get()));
            LblCosto.setText(Float.toString(i.getCosto().get()));

        } else {
          
        	 LblData.setText("");
             LblCliente.setText("");
             LblRegistratore.setText("");
             LblTipo.setText("");
             LblChiusure.setText("");
             LblNote.setText("");
             LblPrezzo.setText("");
             LblCosto.setText("");
        }
    }
    
    @FXML
    private void eliminaIntervento() {
    Interventi interv =IntTable.getSelectionModel().getSelectedItem();
    if (interv != null) {
    	String den="";
    	for(int j=0;j<model.elencocl().size();j++){
    		if(model.elencocl().get(j).getP_iva().equals(interv.getCliente().get())){
    			den=model.elencocl().get(j).getDenominazione();
    		}
    	}
    	
       model.elimIntervento(interv);
       ClientiReg cr=null;
       for(int k=0;k<model.regDelCliente(den).size();k++){
   		if(model.regDelCliente(den).get(k).getRegistr().get().equals(interv.getRegistratore().get())){
   			cr=model.regDelCliente(den).get(k);
   		}
   	}
       List<Interventi>intDelC=new ArrayList<Interventi>(model.intDelCliente(interv.getCliente().get(), interv.getRegistratore().get()));
       if(!intDelC.get(0).getData().get().equals(cr.getUltimoInt().get())){
    	   cr.setultimoint(intDelC.get(0).getData().get());
    	   if(intDelC.get(0).getTipo_int().get().equals("NUOVA INSTALL. ESITO OK") || intDelC.get(0).getTipo_int().get().equals("VERIFICA ANNUALE ESITO OK") || intDelC.get(0).getTipo_int().get().equals("NUOVA INSTALL. ESITO NO")){
	    		 cr.setAttivo(true);
	    	}
	    	else{
	    	     cr.setAttivo(false);
	    	}
    	   model.aggiornaDopoElimint(cr);
       }
       
       ObservableList<Interventi> i = FXCollections.observableArrayList(model.elencoInterventi());
       IntTable.setItems(i);

    } else {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Elemento non selezionato");
        alert.setContentText("Selezionare un intervento.");

        alert.showAndWait();
    }
    
    }
    
    @FXML
    private void apriModifica() {
        Interventi interv = IntTable.getSelectionModel().getSelectedItem();
        if (interv != null) {
            boolean okClicked = main.MostraIntDaMod(interv);
            if (okClicked) {
                mostraDettagliIntervento(interv);
            }
            ObservableList<Interventi> i = FXCollections.observableArrayList(model.elencoInterventi());
            IntTable.setItems(i);
        } else {
           
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Elemento non selezionato");
            alert.setContentText("Selezionare un intervento.");

            alert.showAndWait();
        }
    }

    
    
    @FXML
    void initialize() {
        assert TipoColonna != null : "fx:id=\"TipoColonna\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert DataColonna != null : "fx:id=\"DataColonna\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert MatrColonna != null : "fx:id=\"MatrColonna\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert ClienteColonna != null : "fx:id=\"ClienteColonna\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert BntElimina != null : "fx:id=\"BntElimina\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert IntTable != null : "fx:id=\"IntTable\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblNote != null : "fx:id=\"LblNote\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblTipo != null : "fx:id=\"LblTipo\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblData != null : "fx:id=\"LblData\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblCliente != null : "fx:id=\"LblCliente\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblCosto != null : "fx:id=\"LblCosto\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblRegistratore != null : "fx:id=\"LblRegistratore\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert BtnModifica != null : "fx:id=\"BtnModifica\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblChiusure != null : "fx:id=\"LblChiusure\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        assert LblPrezzo != null : "fx:id=\"LblPrezzo\" was not injected: check your FXML file 'FinestraElencoInt.fxml'.";
        
        
        MatrColonna.setCellValueFactory(cellData -> cellData.getValue().getRegistratore());
        ClienteColonna.setCellValueFactory(cellData -> cellData.getValue().getCliente());
        DataColonna.setCellValueFactory(cellData -> cellData.getValue().getData());
        TipoColonna.setCellValueFactory(cellData -> cellData.getValue().getTipo_int());
        mostraDettagliIntervento(null);
        IntTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> mostraDettagliIntervento(newValue));
    }
}

