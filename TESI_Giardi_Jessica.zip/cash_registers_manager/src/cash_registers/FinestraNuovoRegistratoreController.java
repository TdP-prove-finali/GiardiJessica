/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

	import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import cash_register_model.Clienti;
import cash_register_model.ClientiReg;
import cash_register_model.Model;
import cash_register_model.Modelli;
import cash_register_model.ModelloConverter;
import cash_register_model.Registratori;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
	import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.stage.Stage;

	public class FinestraNuovoRegistratoreController {
		private Stage dialogStage;
		private Clienti cliente;
		private Model model;
		private Main main;
		private Registratori reg;
		private ClientiReg creg;
		

	    @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private TextField TxtCap;

	    @FXML
	    private TextField TxtProvincia;

	    @FXML
	    private TextField TxtMatricola;

	    @FXML
	    private TextField TxtVia;

	    @FXML
	    private Label LblCliente;

	    @FXML
	    private TextField TxtCitta;

	    @FXML
	    private Label LblCap;
	    

	    @FXML
	    private Button bntconferma;

	    @FXML
	    private Label LblCitta;

	    @FXML
	    private Label LblProvincia;
	    
	    @FXML
	    private ChoiceBox<Modelli> ChoiceModello;
	    
	    public void setMain(Main main) {
	        this.main = main;
	        ObservableList<Modelli> t = FXCollections.observableArrayList(model.elencomod());
	        ChoiceModello.setItems(t);
	        ChoiceModello.setConverter(new ModelloConverter());
	      

	    }
	    
	    public void setModel(Model model){
	   	   this.model=model;
	   	
	      }
	     
	     
	     public void setDialogStage(Stage dialogStage) {
	         this.dialogStage = dialogStage;
	     }
	     
	     public void setDatiNuovoReg(Clienti i,Registratori reg,ClientiReg creg) {
	         this.cliente = i;
	         this.reg=reg;
	         this.creg=creg;
	        
	         String den="";
	         String via="";
	         String cap="";
	         String citta="";
	         String prov="";
	         for(int j=0;j<model.elencocl().size();j++){
	         	if(model.elencocl().get(j).getP_iva().equals(i.getP_iva())){
	         		den=model.elencocl().get(j).getDenominazione();
	         		via=model.elencocl().get(j).getVia_sede();
	         		cap=model.elencocl().get(j).getCap_sede();
	         		citta=model.elencocl().get(j).getCitta_sede();
	         		prov=model.elencocl().get(j).getProvincia_sede();
	         	}
	         }
	         
	         if(reg.getModel_rg()!=null){
	         int ind=0;
	         for(int k=0; k<model.elencomod().size();k++){
	        	
	        	 if(model.elencomod().get(k).getModello().toString().equals(reg.getModel_rg().toString())){
	        		 ind =k;
	        	 }
	         }
	         ChoiceModello.getSelectionModel().select(ind);
	         TxtMatricola.setText(reg.getMatricola().toString());
	         }
	        
	         LblCliente.setText(den);
	         TxtVia.setText(via);
	         TxtCap.setText(cap);
	         TxtCitta.setText(citta);
	         TxtProvincia.setText(prov);
	     }
	    
	     @FXML
	     void ConfermaReg() {
	    	 if(reg.getMatricola()==null){
	    	        if (isInputValid()) {
	    	            reg.setMatricola(TxtMatricola.getText());
	    	            reg.setModel_rg(ChoiceModello.getSelectionModel().getSelectedItem().getModello());
	    	           
		                ClientiReg creg=new ClientiReg(null, null, null, null, null, null, false, null);
	    	            creg.setclient(cliente.getP_iva().toString());
	    	            creg.setregistr(TxtMatricola.getText());
	    	            creg.setAttivo(false);
	    	            creg.setCap_reg(TxtCap.getText());
	    	            creg.setCitta_reg(TxtCitta.getText());
	    	            creg.setVia_reg(TxtVia.getText());
	    	            creg.setProv_reg(TxtProvincia.getText());
	    	            creg.setultimoint(LocalDate.MIN);
	    	            List<Registratori>regist=new ArrayList<Registratori>(model.elencoreg());
	    	            Boolean esiste=false;
	    	            for(int i=0;i<regist.size();i++){
	    	            	if(regist.get(i).getMatricola().equals(creg.getRegistr().get())){
	    	            		esiste=true;
	    	            	}
	    	            }
	    	            if(esiste){
	    	            	model.assegnaReg(cliente, reg, creg);
	    	            }
	    	            else{
	    	            model.aggiungiReg(cliente, reg, creg);
	    	            }
	    	    		 dialogStage.close();
	    	        }
	    	    	}
	    	    	else{
	    	    		if(isInputValid()){
	    	    	     ClientiReg c=new ClientiReg(null, null, null, null, null, null, false, null);
	    	    	     c.setclient(creg.getClient().get());
	    	    	     c.setregistr(creg.getRegistr().get());
	    	    		 c.setAttivo(creg.getAttivo().get());
	    	    		 c.setCap_reg(creg.getCap_reg().get());
	    	    		 c.setCitta_reg(creg.getCitta_reg().get());
	    	    		 c.setProv_reg(creg.getProvincia_reg().get());
	    	    		 c.setultimoint(creg.getUltimoInt().get());
	    	    		 c.setVia_reg(creg.getVia_reg().get());
	    	    	   
	    	    	     reg.setMatricola(TxtMatricola.getText());
		    	         reg.setModel_rg(ChoiceModello.getSelectionModel().getSelectedItem().getModello());
	    	    	     creg.setclient(cliente.getP_iva().toString());
	    	    	     creg.setregistr(TxtMatricola.getText());
		    	         creg.setAttivo(false);
		    	         creg.setCap_reg(TxtCap.getText());
		    	         creg.setCitta_reg(TxtCitta.getText());
		    	         creg.setVia_reg(TxtVia.getText());
		    	         creg.setProv_reg(TxtProvincia.getText());
		    	         creg.setultimoint(LocalDate.MIN);
		    	        
	    	    		model.modificaReg(cliente, reg, creg, c);
	    	    		 dialogStage.close();
	    	    		}
	    	    	}
         
	     }
	     
	     private boolean isInputValid() {
	            String errorMessage = "";

	            if (TxtMatricola.getText() == null || TxtMatricola.getText().length() == 0) {
	                errorMessage += "Inserire la matricola del registratore di cassa!\n"; 
	            }
	            else{

	            	String m=TxtMatricola.getText();
	            	if( m.length() != 8)
	            		errorMessage +="La matricola deve essere di 8 cifre.\n";
	            	else{
	            		
	            		 for(int i=0; i<8; i++ ){
	                         char c = m.charAt(i);
	                         if( ! ( c>='0' && c<='9' ) )
	                         	errorMessage +="Matricola non valida.\n";
	                     
	            		 }
	            	}
	            	
	            
	            }
	            if (TxtVia.getText() == null || TxtVia.getText().length() == 0) {
	                errorMessage += "Inserire la via del luogo di esercizio!\n"; 
	            }
	            if (TxtCap.getText() == null || TxtCap.getText().length() == 0) {
	                errorMessage += "Inserire il CAP del luogo di esercizio!\n"; 
	            }
	            else {
	            	String cap=TxtCap.getText();
	            	if( cap.length() != 5 )
	            		errorMessage +="Il CAP deve essere di 5 cifre.\n";
	            	else{
	            		
	            		 for(int i=0; i<5; i++ ){
	                         char c = cap.charAt(i);
	                         if( ! ( c>='0' && c<='9' ) )
	                         	errorMessage +="CAP non valido.\n";
	                     
	            		 }
	            	}
	            	
	            }
	            if (ChoiceModello.getSelectionModel().getSelectedItem()== null) {
	                errorMessage += "Selezionare un modello!\n"; 
	            }
	            if (TxtCitta.getText() == null || TxtCitta.getText().length() == 0) {
	                errorMessage += "Inserire la citt� del luogo di esercizio!\n"; 
	            }
	            if (TxtProvincia.getText() == null || TxtProvincia.getText().length() == 0) {
	                errorMessage += "Inserire la provincia del luogo di attivit�!\n"; 
	            }
	            else{
	            	String pro=TxtProvincia.getText();
	            	if( pro.length() != 2 )
	            		errorMessage +="La provincia deve essere di 2 caratteri.\n";
	            	else{
	                    String cf2 = pro.toUpperCase();
	                    for(int i=0; i<2; i++ ){
	                    char c = cf2.charAt(i);
	                    if( ! (c>='A' && c<='Z' ) )
	                    	errorMessage +="Provincia non valida.\n";
	                }
	            	}
	            }
	           
	            if (errorMessage.length() == 0) {
	                return true;
	            } else {
	                // Show the error message.
	                Alert alert = new Alert(AlertType.ERROR);
	                alert.initOwner(dialogStage);
	                alert.setTitle("Valori inseriti non corretti");
	                alert.setHeaderText("Correggere i valori inseriti.");
	                alert.setContentText(errorMessage);

	                alert.showAndWait();

	                return false;
	            }

	        }

	    @FXML
	    void initialize() {
	        assert TxtCap != null : "fx:id=\"TxtCap\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert TxtProvincia != null : "fx:id=\"TxtProvincia\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert TxtMatricola != null : "fx:id=\"TxtMatricola\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert TxtVia != null : "fx:id=\"TxtVia\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert LblCliente != null : "fx:id=\"LblCliente\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert TxtCitta != null : "fx:id=\"TxtCitta\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert LblCap != null : "fx:id=\"LblCap\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert LblCitta != null : "fx:id=\"LblCitta\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert LblProvincia != null : "fx:id=\"LblProvincia\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert ChoiceModello != null : "fx:id=\"ChoiceModello\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	        assert bntconferma != null : "fx:id=\"bntconferma\" was not injected: check your FXML file 'FinestraNuovoRegistratore.fxml'.";
	    }
	}



