/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import cash_register_model.Clienti;
import cash_register_model.Model;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class FinestraModifClienteController {
	private Stage dialogStage;
	private Clienti cliente;

	private Model model;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField txtCap;

    @FXML
    private TextField txtPiva;

    @FXML
    private Label denominazLabel;

    @FXML
    private Button cmdConferma;

    @FXML
    private TextField txtDenomiz;

    @FXML
    private TextField txtCodfisc;

    @FXML
    private TextField txtCitta;

    @FXML
    private TextField txtVia;

    @FXML
    private Button cmdCancella;

    @FXML
    private TextField txtPro;
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    public Clienti setCliente(Clienti cliente) {
        this.cliente = cliente;
        
        txtDenomiz.setText(cliente.getDenominazione());
        txtVia.setText(cliente.getVia_sede());
        txtCitta.setText(cliente.getCitta_sede());
        txtCap.setText(cliente.getCap_sede());
        txtPro.setText(cliente.getProvincia_sede());
        txtCodfisc.setText(cliente.getCod_fisc());
        txtPiva.setText(cliente.getP_iva());
    return cliente;
    }
    
  
    
    @FXML
    private void confermaCliente() throws MySQLIntegrityConstraintViolationException {
    	
    	if(cliente.getP_iva()==null){
        if (isInputValid()) {
            cliente.setDenominazione(txtDenomiz.getText());
            cliente.setVia_sede(txtVia.getText());
            cliente.setCap_sede(txtCap.getText());
            cliente.setCitta_sede(txtCitta.getText());
            cliente.setProvincia_sede(txtPro.getText());
            cliente.setCod_fisc(txtCodfisc.getText());
            cliente.setP_iva(txtPiva.getText());
            model.aggiungiCl(cliente);
            dialogStage.close();
        }
    	}
    	else{
    		if(isInputValid()){
    	     Clienti c=new Clienti(null, null, null, null, null, null, null);
    	  
             c.setDenominazione(cliente.getDenominazione());
             c.setVia_sede(cliente.getVia_sede());
             c.setCap_sede(cliente.getCap_sede());
             c.setCitta_sede(cliente.getCitta_sede());
             c.setProvincia_sede(cliente.getProvincia_sede());
             c.setCod_fisc(cliente.getCod_fisc());
             c.setP_iva(cliente.getP_iva());
             cliente.setDenominazione(txtDenomiz.getText());
             cliente.setVia_sede(txtVia.getText());
             cliente.setCap_sede(txtCap.getText());
             cliente.setCitta_sede(txtCitta.getText());
             cliente.setProvincia_sede(txtPro.getText());
             cliente.setCod_fisc(txtCodfisc.getText());
             cliente.setP_iva(txtPiva.getText());
             model.modificaCl(cliente,c);
             dialogStage.close();
    		}
    	}
        }
    
    public void setModel(Model model){
   	   this.model=model;
      }

        private boolean isInputValid() {
            String errorMessage = "";

            if (txtDenomiz.getText() == null || txtDenomiz.getText().length() == 0) {
                errorMessage += "Inserire la denominazione!\n"; 
            }
            else{
            	
            }
            if (txtVia.getText() == null || txtVia.getText().length() == 0) {
                errorMessage += "Inserire la via!\n"; 
            }
            if (txtCap.getText() == null || txtCap.getText().length() == 0) {
                errorMessage += "Inserire il CAP!\n"; 
            }
            else {
            	String cap=txtCap.getText();
            	if( cap.length() != 5 )
            		errorMessage +="Il CAP deve essere di 5 caratteri.\n";
            	else{
            		
            		 for(int i=0; i<5; i++ ){
                         char c = cap.charAt(i);
                         if( ! ( c>='0' && c<='9' ) )
                         	errorMessage +="CAP non valido.\n";
                     
            		 }
            	}
            	
            }
            if (txtCitta.getText() == null || txtCitta.getText().length() == 0) {
                errorMessage += "Inserire la citt�!\n"; 
            }
            if (txtPro.getText() == null || txtPro.getText().length() == 0) {
                errorMessage += "Inserire la provincia!\n"; 
            }
            else{
            	String pro=txtPro.getText();
            	if( pro.length() != 2 )
            		errorMessage +="La provincia deve essere di 2 caratteri.\n";
            	else{
                    String cf2 = pro.toUpperCase();
                    Boolean t=false;
                    for(int i=0; i<2; i++ ){
                    char c = cf2.charAt(i);
                    if( ! (c>='A' && c<='Z' ) )
                    	t=true;
                    	
                }
                    if(t){
                    	errorMessage +="Provincia non valida.\n";
                    }
            	}
            }
            if (txtCodfisc.getText() == null || txtCodfisc.getText().length() == 0) {
                errorMessage += "Inserire il codice fiscale!\n"; 
            }
            else{
            	String cf=txtCodfisc.getText();
            	if( cf.length() != 16 ){
            		if(cf.length()==11 && cf.equals(txtPiva.getText())){
            			
            		}
            		else{
            		errorMessage +="Codice fiscale non valido.\n";
            		}
            	}else{
            		Boolean errore =false;
                    String cf2 = cf.toUpperCase();
                    for(int i=0; i<16; i++ ){
                    char c = cf2.charAt(i);
                    if( ! ( c>='0' && c<='9' || c>='A' && c<='Z' ) )
                    	errore=true;
                }
                char s = 0;
                for(int  i=0; i<=5; i++ ){
                	s=cf2.charAt(i);
                	 if( ! ( s>='A' && s<='Z' ) )
                		 errore=true;
                }
                if( ! ( cf2.charAt(8)>='A' && cf2.charAt(8)<='Z')|| !(cf2.charAt(11)>'A' && cf2.charAt(11)<='Z') || !(cf2.charAt(15)>'A' && cf2.charAt(15)<='Z') )
                	errore=true;
                
                for(int  i=6; i<=7; i++ ){
                	s=cf2.charAt(i);
                	 if( ! ( s>='0' && s<='9' ) )
                		 errore=true;
                }
                for(int  i=9; i<=10; i++ ){
                	s=cf2.charAt(i);
                	 if( ! ( s>='0' && s<='9' ) )
                		 errore=true;
                }
                for(int  i=12; i<=14; i++ ){
                	s=cf2.charAt(i);
                	 if( ! ( s>='0' && s<='9' ) )
                		 errore=true;
                }    	
                
                if(errore){
                	
                		errorMessage +="Codice fiscale non valido.\n";
                }
            	
                
            	} 
            }
            if (txtPiva.getText() == null || txtPiva.getText().length() == 0) {
                errorMessage += "Inserire la partita iva!\n"; 
            }
            else{
            	String pi=txtPiva.getText();
            	 if( pi.length() != 11 )
            		 errorMessage += "La partita iva deve avere 11 cifre!\n"; 
            	 else{
            	    for(int i=0; i<11; i++ ){
            	        if( pi.charAt(i) < '0' || pi.charAt(i) > '9' )
            	        	errorMessage += "Partita iva non valida!\n"; 
            	    }
            	   
            	 }
            }
            
            if (errorMessage.length() == 0) {
                return true;
            } else {
                // Show the error message.
                Alert alert = new Alert(AlertType.ERROR);
                alert.initOwner(dialogStage);
                alert.setTitle("Valori inseriti non corretti");
                alert.setHeaderText("Correggere i valori inseriti.");
                alert.setContentText(errorMessage);

                alert.showAndWait();

                return false;
            }

        }

    @FXML
    void initialize() {
        assert txtCap != null : "fx:id=\"txtCap\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtPiva != null : "fx:id=\"txtPiva\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert denominazLabel != null : "fx:id=\"denominazLabel\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert cmdConferma != null : "fx:id=\"cmdConferma\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtDenomiz != null : "fx:id=\"txtDenomiz\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtCodfisc != null : "fx:id=\"txtCodfisc\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtCitta != null : "fx:id=\"txtCitta\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtVia != null : "fx:id=\"txtVia\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert cmdCancella != null : "fx:id=\"cmdCancella\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";
        assert txtPro != null : "fx:id=\"txtPro\" was not injected: check your FXML file 'NuovoModifCliente.fxml'.";

        

        
    }

}
