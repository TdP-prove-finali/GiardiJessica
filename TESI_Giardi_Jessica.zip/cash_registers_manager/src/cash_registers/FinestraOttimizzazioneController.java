/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_registers;

import java.net.URL;
import java.util.ResourceBundle;

import cash_register_model.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class FinestraOttimizzazioneController {

	private Stage dialogStage;
	private Model model;
	private Main main;
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField TxtCostoVer;

    @FXML
    private TextField TxtCostoInst;

    @FXML
    private TextField TxtPrInst;

    @FXML
    private TextField TxtPrVer;

    @FXML
    private Button CmdCalcola;
    
    @FXML
    private TextField TxtTecnici;

    @FXML
    private Label LblResult;

    @FXML
    private ComboBox<String> ComboMese;

    @FXML
    private TextField TxtIntGg;

    @FXML
    private TextField TxtCostoAb;

    @FXML
    private TextField TxtGgLav;
    
    @FXML
    private TextField Txtcmax;
    
    @FXML 
    private TextField txtnuovimax;
    
    
    
    
    public void setMain(Main main) {
        this.main = main;
        ObservableList<String> c = FXCollections.observableArrayList("Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre");
        
     	ComboMese.setItems(c);
     	
       
    }
    
   
    
    public void setModel(Model model){
  	   this.model=model;
  	
     }
    
    
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }
    
    @FXML
    public void calcolaPL() throws Exception{
    	if(isInputValid()){
    	float prver=Float.parseFloat(TxtPrVer.getText());
    	float prinst=Float.parseFloat(TxtPrInst.getText());
    	float costover=Float.parseFloat(TxtCostoVer.getText());
    	float costoinst=Float.parseFloat(TxtCostoInst.getText());
    	int mese=ComboMese.getSelectionModel().getSelectedIndex();
    	int tecnici=Integer.parseInt(TxtTecnici.getText());
    	int intgg=Integer.parseInt(TxtIntGg.getText());
    	int gglav=Integer.parseInt(TxtGgLav.getText());
    	float costoab=Float.parseFloat(TxtCostoAb.getText());
    	float cmax=Float.parseFloat(Txtcmax.getText());
    	int nuovimax=Integer.parseInt(txtnuovimax.getText());
    	LblResult.setText(model.ottimizz(costover, costoinst, prver, prinst, costoab, mese, tecnici, intgg, gglav, cmax,nuovimax));
    	}
    	}
    
    private boolean isInputValid() {
        String errorMessage = "";

        if (ComboMese.getSelectionModel().getSelectedItem() == null) {
            errorMessage += "Selezionare un mese!\n"; 
        }
        
        if (TxtCostoAb.getText() == null || TxtCostoAb.getText().length() == 0) {
            errorMessage += "Inserire il costo sostenuto per il rinnovo dell'abilitazione.\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(TxtCostoAb.getText());
        		if(p<=0){
        			errorMessage+="Costo sostenuto per il rinnovo dell'abilitazione non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Costo sostenuto per il rinnovo dell'abilitazione non valido.\n";
    		}

        	
        }
        if (Txtcmax.getText() == null || Txtcmax.getText().length() == 0) {
            errorMessage += "Inserire il costo aggiuntivo massimo che si intende sostenere nell'incremento del numero di installazioni e verifiche.\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(Txtcmax.getText());
        		if(p<=0){
        			errorMessage+="Costo massimo aggiuntivo non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Costo massimo aggiuntivo non valido.\n";
    		}

        	
        }
        if (TxtCostoVer.getText() == null || TxtCostoVer.getText().length() == 0) {
            errorMessage += "Inserire il costo medio di una verificazione periodica!\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(TxtCostoVer.getText());
        		if(p<=0){
        			errorMessage+="Costo medio di verificazione periodica non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Costo medio di verificazione periodica non valido.\n";
    		}

        	
        }
        if (TxtGgLav.getText() == null || TxtGgLav.getText().length() == 0) {
            errorMessage += "Inserire il numero di giorni lavorativi settimanali.\n"; 
        }
        else{
        	try{
        		int p=Integer.parseInt(TxtGgLav.getText());
        		if(p>7 || p<=0){
        			errorMessage+="Numero giorni lavorativi settimanali non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Numero giorni lavorativi settimanali non valido.\n";
    		}

        	
        }
        if (txtnuovimax.getText() == null || txtnuovimax.getText().length() == 0) {
            errorMessage += "Inserire il numero massimo di possibili nuovi clienti.\n"; 
        }
        else{
        	try{
        		int p=Integer.parseInt(TxtGgLav.getText());
        		if(p>7 || p<=0){
        			errorMessage+="Numero massimo di nuovi clienti non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Numero massimo di nuovi clienti non valido.\n";
    		}

        	
        }
        if (TxtCostoInst.getText() == null || TxtCostoInst.getText().length() == 0) {
            errorMessage += "Inserire il costo sostenuto medio per un'installazione!\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(TxtCostoInst.getText());
        		if(p<=0){
        			errorMessage+="Costo medio sostenuto per l'installazione non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Costo medio sostenuto per l'installazione non valido.\n";
    		}
        }
        if (TxtTecnici.getText() == null || TxtTecnici.getText().length() == 0) {
            errorMessage += "Inserire il numero di tecnici abilitati.\n"; 
        }
        else{
        	try{
        		int p=Integer.parseInt(TxtTecnici.getText());
        		if(p<=0){
        			errorMessage+="Numero di tecnici abilitati inserito non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Numero di tecnici abilitati inserito non valido.\n";
    		}

        	
        }
        if (TxtIntGg.getText() == null || TxtIntGg.getText().length() == 0) {
            errorMessage += "Inserire il numero medio di interventi effettuati da ogni tecnico al giorno.\n"; 
        }
        else{
        	try{
        		int p=Integer.parseInt(TxtIntGg.getText());
        		if(p<=0){
        			errorMessage+="Numero medio di interventi al giorno per tecnico non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Numero medio di interventi al giorno per tecnico non valido.\n";
    		}

        	
        }
        if (TxtPrInst.getText() == null || TxtPrInst.getText().length() == 0) {
            errorMessage += "Inserire il prezzo medio di un'installazione.\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(TxtCostoAb.getText());
        
        		if(p<=0){
        			errorMessage+="Prezzo medio dell'installazione non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Prezzo medio dell'installazione non valido.\n";
    		}

        	
        }
        if (TxtPrVer.getText() == null || TxtPrVer.getText().length() == 0) {
            errorMessage += "Inserire il prezzo medio di una verificazione.\n"; 
        }
        else{
        	try{
        		Float p=Float.parseFloat(TxtCostoAb.getText());
        		if(p<=0){
        			errorMessage+="Prezzo medio di verificazione non valido.\n";
        		}
        	} catch (NumberFormatException e) {
    			errorMessage+="Prezzo medio di verificazione non valido.\n";
    		}

        	
        }
        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Valori inseriti non corretti");
            alert.setHeaderText("Correggere i valori inseriti.");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }

    }
    

    @FXML
    void initialize() {
        assert TxtCostoVer != null : "fx:id=\"TxtCostoVer\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtCostoInst != null : "fx:id=\"TxtCostoInst\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtPrInst != null : "fx:id=\"TxtPrInst\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtPrVer != null : "fx:id=\"TxtPrVer\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert CmdCalcola != null : "fx:id=\"CmdCalcola\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtTecnici != null : "fx:id=\"TxtTecnici\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert LblResult != null : "fx:id=\"LblResult\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert ComboMese != null : "fx:id=\"ComboMese\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtIntGg != null : "fx:id=\"TxtIntGg\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtCostoAb != null : "fx:id=\"TxtCostoAb\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert TxtGgLav != null : "fx:id=\"TxtGgLav\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert Txtcmax != null : "fx:id=\"Txtcmax\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
        assert txtnuovimax != null : "fx:id=\"txtnuovimax\" was not injected: check your FXML file 'FinestraOttimizzazione.fxml'.";
    }
}

