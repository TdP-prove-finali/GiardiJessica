/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_register_model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Registratori {

	private final StringProperty matricola;
	private final StringProperty model_rg;
	
	public Registratori(String matricola, String model_rg) {
		super();
	
		this.matricola =new SimpleStringProperty(matricola);
		this.model_rg = new SimpleStringProperty(model_rg);
		
	}
	public String getMatricola() {
		return matricola.get();
	}
	public void setMatricola(String matricola) {
		
		this.matricola.set(matricola);
	}
	public String getModel_rg() {
		return model_rg.get();
	}
	public void setModel_rg(String model_rg) {
		this.model_rg.set(model_rg);
	}
	
	
	public StringProperty matricolaProperty() {
        return matricola;
    }
	
	public StringProperty modelProperty() {
        return model_rg;
    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((matricola == null) ? 0 : matricola.hashCode());
		result = prime * result + ((model_rg == null) ? 0 : model_rg.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Registratori other = (Registratori) obj;
		if (matricola == null) {
			if (other.matricola != null)
				return false;
		} else if (!matricola.equals(other.matricola))
			return false;
		if (model_rg == null) {
			if (other.model_rg != null)
				return false;
		} else if (!model_rg.equals(other.model_rg))
			return false;
		return true;
	}
	
	

	
}
