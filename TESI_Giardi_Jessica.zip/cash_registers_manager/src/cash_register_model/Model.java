/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_register_model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import cash_registers_db.RegisterDAO;
import it.ssc.log.SscLogger;
import it.ssc.pl.milp.ConsType;
import it.ssc.pl.milp.Constraint;
import it.ssc.pl.milp.GoalType;
import it.ssc.pl.milp.LP;
import it.ssc.pl.milp.LPException;
import it.ssc.pl.milp.LinearObjectiveFunction;
import it.ssc.pl.milp.SimplexException;
import it.ssc.pl.milp.Solution;
import it.ssc.pl.milp.SolutionType;
import it.ssc.pl.milp.Variable;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class Model {
	
	private RegisterDAO dao= new RegisterDAO();
	private List<Clienti>cl=new ArrayList<Clienti>();
	 private Stage dialogStage;
	
	public List<Clienti> elencocl(){
		return dao.elencoClienti();
	}
	
	public void aggiungiCl(Clienti c){
		dao.aggiungiCliente(c);
	}
	
	public void modificaCl(Clienti c,Clienti cliente){
		if(regDelCliente(c.getDenominazione().toString()).size()!=0){
			 Alert alert = new Alert(AlertType.CONFIRMATION);
			
             alert.initOwner(dialogStage);
             alert.setHeaderText("Procedere con la modifica?");
             alert.setContentText("Il cliente � associato ad altre tabelle. Se si proceder� alla modifica tutti i record associati saranno aggiornati.");
             Optional<ButtonType> result = alert.showAndWait();
             if (result.get() == ButtonType.OK){
            	 dao.modificaCliente(c,cliente);
             } else {
                alert.close();
             }
		}
             else{
            	 dao.modificaCliente(c,cliente);
             }
		
	
	}
	public List<Modelli> elencomod(){
		return dao.elencoModelli();
	}
	
	public List<Interventi> elencoInterventi(){
		return dao.elencoInterventi();
	}
	
	public List<String> elenconomicl(){
		List<String>nomi=new ArrayList<String>();
		for(int i=0;i<dao.elencoClienti().size();i++){
			nomi.add(elencocl().get(i).getDenominazione());
			
		}
		return nomi;
	}

	public void aggiungiMod(Modelli m){
		dao.aggiungiMdello(m);
	}
	public void modificaMod(Modelli m, Modelli modello){
		Boolean vero=false;

		for(int i=0; i<elencoreg().size();i++){
		if(elencoreg().get(i).getModel_rg().toString().equals(modello.getModello().toString())){
			vero=true;

            }
		}
		if(vero){
			 Alert alert = new Alert(AlertType.CONFIRMATION);
				
	            alert.initOwner(dialogStage);
	            alert.setHeaderText("Procedere con la modifica?");
	            alert.setContentText("Il modello � associato ad altre tabelle. Se si proceder� alla modifica tutti i record associati saranno aggiornati.");
	            Optional<ButtonType> result = alert.showAndWait();
	            if (result.get() == ButtonType.OK){
	              	 dao.modificaModello(m, modello);
	               } 
	            else{
	            	alert.close();
	            }
		}
		else
           	 dao.modificaModello(m, modello);
            }
	
	
	public List<ClientiReg> regDelCliente(String denominaz){
		List<ClientiReg>cr=new ArrayList<ClientiReg>();
		String piva="";
		  
		
		
		for(int i=0;i<dao.elencoClienti().size();i++){
			if(dao.elencoClienti().get(i).getDenominazione().equals(denominaz)){
				piva=dao.elencoClienti().get(i).getP_iva();
				
				
			}
		}
		for(int j=0;j<dao.elencoClienti_reg().size();j++){
		
			if(dao.elencoClienti_reg().get(j).getClient().get().equals(piva)){
				cr.add(dao.elencoClienti_reg().get(j));
				
				
				
			}
		}
		
		
		return cr;
		
	}
	
	public List<Tipi_interventi> elencotipi(){
		return dao.elencoTipi();
	}
	
	public List<Registratori> elencoreg(){
		return dao.elencoReg();
	}
	
	public void aggiungiReg(Clienti c, Registratori r, ClientiReg cr){
		dao.aggiungiRegistratore(c, r, cr);
	}
	
	public void assegnaReg(Clienti c, Registratori r, ClientiReg cr){
		dao.assegnaRegistratore(c, r, cr);
	}
	
	public void modificaReg(Clienti c,Registratori r,ClientiReg cr,ClientiReg iniz){
		dao.modificaRegistratore(c, r, cr, iniz);
	}
	
	public void eliminaReg(ClientiReg cr){
		dao.eliminaRegistratore(cr);
	}
	
	public List<Interventi> intDelCliente(String c,String m){
		return dao.elencoIntDelCliente(c,m);
	}
	
	public List<ClientiReg> elencoScadenze(int mese){
		List<ClientiReg>r=new ArrayList<ClientiReg>(dao.elencoClienti_reg());
		List<ClientiReg>selezionati=new ArrayList<ClientiReg>();
		LocalDate d=null;
		
		for(int i=0;i<r.size();i++){
		
			LocalDate today = LocalDate.now();
			if(r.get(i).getUltimoInt().get().getMonthValue()==mese && today.getMonthValue()<=mese && r.get(i).getAttivo().get()==true && r.get(i).getUltimoInt().get().getYear()==(today.getYear()-1)){
				selezionati.add(r.get(i));
			}
			else{
				if(r.get(i).getUltimoInt().get().getMonthValue()==mese && today.getMonthValue()>mese && r.get(i).getAttivo().get()==true && r.get(i).getUltimoInt().get().getYear()==today.getYear()){
					selezionati.add(r.get(i));
				}
			}
			
		}
		return selezionati;
		
	}
	public void aggiungiInt(Interventi i, ClientiReg cr){
		dao.aggiungiIntervento(i, cr);
	}
	
	public void modifInt(Interventi i,ClientiReg cr,Interventi vecchioi){
		dao.modificaIntervento(i, cr,vecchioi);
	}
	
	public void modifInt2(Interventi i,ClientiReg cr,Interventi vecchioi){
		dao.modificaIntervento2(i, cr,vecchioi);
	}
	
	public void elimCliente(Clienti c){
		dao.eliminaCliente(c);
	}
	
	public void elimModello(Modelli m){
		dao.eliminaModello(m);
	}
	
	public void aggiornaDopoElimint(ClientiReg cr){
		dao.aggiornaDopoElimInt(cr);
	}
	
	public void elimIntervento(Interventi i){
		dao.eliminaIntervento(i);
	}
	public List<Interventi> regInEsaurimento(){
		List<ClientiReg>clreg=new ArrayList<ClientiReg>(dao.elencoClienti_reg());
		List<Interventi>interv=new ArrayList<Interventi>(dao.elencoInterventi());
		List<Interventi>selez=new ArrayList<Interventi>();
		for(int i=0;i<interv.size();i++){
			if(interv.get(i).getChiusure().get()>1650 && (!interv.get(i).getTipo_int().equals("DEFISCALIZZ. ESITO NO") || !	interv.get(i).getTipo_int().equals("DEFISCALIZZ. ESITO OK"))){
			   for(int j=0; j<clreg.size();j++){
				   if(interv.get(i).getCliente().get().equals(clreg.get(j).getClient().get()) && interv.get(i).getRegistratore().get().equals(clreg.get(j).getRegistr().get()) && interv.get(i).getData().get().equals(clreg.get(j).getUltimoInt().get()) && clreg.get(j).getAttivo().get()==true){
					   if(!selez.contains(interv.get(i))){
					   selez.add(interv.get(i));
					   }
				   }
			   }
			}
		}
		return selez;
	}
	
	public String ottimizz(float cv,float ci,float pv, float pi, float costoab,int mese,int tecnici,int intgg,int ggap,float cmax,float nuovimax) throws Exception{
		
		Float coeffVer=pv-cv;
		Float coeffInst=pi-ci;
		Float costoMensAb=costoab/12;
		Float guadMens=(float) 0;
		Float costoMens=(float) 0;
		LocalDate oggi= LocalDate.now();
		int nint=tecnici*intgg*4*ggap;
		String stampa="";
		
		for(int i=0;i<elencoInterventi().size();i++){
			if(elencoInterventi().get(i).getData().get().getMonthValue()==mese && elencoInterventi().get(i).getData().get().getYear()==oggi.getYear()-1){
			guadMens+=elencoInterventi().get(i).getPrezzo().get();
			costoMens+=elencoInterventi().get(i).getCosto().get();
			}
		}
		Float coeffTre=guadMens-costoMens-costoMensAb;

		 double[] c= { coeffVer, coeffInst, coeffTre }; 
	        LinearObjectiveFunction fo = new LinearObjectiveFunction(c, GoalType.MAX);
	         
	        ArrayList< String > constraints = new ArrayList< String >();
	        
	        constraints.add("x1 +x2       <= "+nint);
	        constraints.add(cv+"x1 + "+ci+"X2  <= "+cmax);
	        constraints.add("x1 +x2             <= "+nuovimax);
	        
	        ArrayList< Constraint > const_upper_lower = new ArrayList< Constraint >();
	        const_upper_lower.add(new Constraint(new Double[] { null, null,(double) 1} , ConsType.UPPER,null));
	        const_upper_lower.add(new Constraint(new double[] { 0, 0,1} , ConsType.LOWER,null));
	         
	        LP lp = new LP(constraints,const_upper_lower,fo); 
	        SolutionType solution_type=lp.resolve();
	         
	        if(solution_type==SolutionType.OPTIMUM) {
	            Solution soluzione=lp.getSolution();
	            
	            for(Variable var:soluzione.getVariables()) {
	            	if(var.getName().equals("X1")){
	            		Double d=var.getValue();
	            		int v=(int)d.doubleValue();
	            	stampa+="Numero verifiche fiscali aggiuntive : "+v+"\n";
	            	}
	            	if(var.getName().equals("X2")){
	            		Double d=var.getValue();
	            		int v=(int)d.doubleValue();
	            	stampa+="Numero installazioni aggiuntive : "+v+"\n";
            	}
	          
	                
	            }
	            Double ott=soluzione.getOptimumValue();
	            int o=   (int)ott.doubleValue();                        
	            
	            stampa+="Guadagno ottimo: "+o+",00 �";
	        }

	        return stampa;

	}
	
	
}
