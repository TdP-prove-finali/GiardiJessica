/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_register_model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Modelli {
	
	private final StringProperty modello;
	private final StringProperty marchio;
	private final StringProperty logo_tipo;
	public Modelli(String modello, String marchio, String logo_tipo) {
		super();
		this.modello = new SimpleStringProperty(modello);
		this.marchio = new SimpleStringProperty(marchio);
		this.logo_tipo = new SimpleStringProperty(logo_tipo);
		
	}
	public String getModello() {
		return modello.get();
	}
	public void setModello(String modello) {
		this.modello.set(modello);
	}
	
	public String getMarchio() {
		return marchio.get();
	}
	public void setMarchio(String marchio) {
		this.marchio.set(marchio);
	}
	public String getLogo_tipo() {
		return logo_tipo.get();
	}
	public void setLogo_tipo(String logo_tipo) {
		this.logo_tipo.set(logo_tipo);
	}
	
	public StringProperty modelloProperty() {
        return modello;
    }
	
	public StringProperty marchioProperty() {
        return marchio;
    }
	
	public StringProperty logoTipoProperty() {
        return logo_tipo;
    }
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((logo_tipo == null) ? 0 : logo_tipo.hashCode());
		result = prime * result + ((marchio == null) ? 0 : marchio.hashCode());
		result = prime * result + ((modello == null) ? 0 : modello.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Modelli other = (Modelli) obj;
		if (logo_tipo == null) {
			if (other.logo_tipo != null)
				return false;
		} else if (!logo_tipo.equals(other.logo_tipo))
			return false;
		if (marchio == null) {
			if (other.marchio != null)
				return false;
		} else if (!marchio.equals(other.marchio))
			return false;
		if (modello == null) {
			if (other.modello != null)
				return false;
		} else if (!modello.equals(other.modello))
			return false;
		return true;
	}
	
	

}
