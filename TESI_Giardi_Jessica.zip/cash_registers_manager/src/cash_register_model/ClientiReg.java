/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_register_model;

import java.time.LocalDate;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ClientiReg {
	
	private final StringProperty client;
	private final StringProperty registr;
	private final StringProperty via_reg;
	private final StringProperty cap_reg;
	private final StringProperty citta_reg;
	private final StringProperty provincia_reg;
	private final BooleanProperty attivo;
	private final ObjectProperty<LocalDate> ultimo_int;
	
	public ClientiReg(String client, String registr, String via_reg, String cap_reg,
			String citta_reg, String provincia_reg, Boolean attivo,LocalDate ultimo_int) {
		super();
		this.client = new SimpleStringProperty(client);
		this.registr = new SimpleStringProperty(registr);
		this.via_reg = new SimpleStringProperty(via_reg);
		this.cap_reg = new SimpleStringProperty(cap_reg);
		this.citta_reg=new SimpleStringProperty(citta_reg);
		this.provincia_reg = new SimpleStringProperty(provincia_reg);
		this.attivo = new SimpleBooleanProperty(attivo);
		this.ultimo_int = new SimpleObjectProperty<LocalDate>(ultimo_int);
	}

	public StringProperty getClient() {
		return client;
	}
	
	public ObjectProperty<LocalDate> getUltimoInt() {
		return ultimo_int;
	}

	public StringProperty getRegistr() {
		return registr;
	}

	public StringProperty getVia_reg() {
		return via_reg;
	}

	public StringProperty getCap_reg() {
		return cap_reg;
	}

	public StringProperty getCitta_reg() {
		return citta_reg;
	}

	public StringProperty getProvincia_reg() {
		return provincia_reg;
	}

	public BooleanProperty getAttivo() {
		return attivo;
	}
	
	
	
	public void setclient(String client) {
		this.client.set(client);
	}
	
	public void setultimoint(LocalDate ultimo_int) {
		this.ultimo_int.set(ultimo_int);
	}
	
	public void setregistr(String registr) {
		this.registr.set(registr);
	}
	
	public void setVia_reg(String via_reg) {
		this.via_reg.set(via_reg);
	}
	
	public void setCap_reg(String cap_reg) {
		this.cap_reg.set(cap_reg);
	}
	
	public void setProv_reg(String provincia_reg) {
		this.provincia_reg.set(provincia_reg);
	}
	
	public void setCitta_reg(String citta_reg) {
		this.citta_reg.set(citta_reg);
	}
	
	public void setAttivo(Boolean attivo) {
		this.attivo.set(attivo);
	}

	public StringProperty clientProperty() {
        return client;
    }
	
	public StringProperty registrProperty() {
        return registr;
    }
	
	public StringProperty cittaRegProperty() {
        return citta_reg;
    }
	
	public StringProperty viaRegProperty() {
        return via_reg;
    }
	
	public StringProperty capRegProperty() {
        return cap_reg;
    }
	
	public StringProperty provinciaRegProperty() {
        return provincia_reg;
    }
	
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((attivo == null) ? 0 : attivo.hashCode());
		result = prime * result + ((cap_reg == null) ? 0 : cap_reg.hashCode());
		result = prime * result + ((citta_reg == null) ? 0 : citta_reg.hashCode());
		result = prime * result + ((client == null) ? 0 : client.hashCode());
		result = prime * result + ((provincia_reg == null) ? 0 : provincia_reg.hashCode());
		result = prime * result + ((registr == null) ? 0 : registr.hashCode());
		result = prime * result + ((via_reg == null) ? 0 : via_reg.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClientiReg other = (ClientiReg) obj;
		if (attivo == null) {
			if (other.attivo != null)
				return false;
		} else if (!attivo.equals(other.attivo))
			return false;
		if (cap_reg == null) {
			if (other.cap_reg != null)
				return false;
		} else if (!cap_reg.equals(other.cap_reg))
			return false;
		if (citta_reg == null) {
			if (other.citta_reg != null)
				return false;
		} else if (!citta_reg.equals(other.citta_reg))
			return false;
		if (client == null) {
			if (other.client != null)
				return false;
		} else if (!client.equals(other.client))
			return false;
		if (provincia_reg == null) {
			if (other.provincia_reg != null)
				return false;
		} else if (!provincia_reg.equals(other.provincia_reg))
			return false;
		if (registr == null) {
			if (other.registr != null)
				return false;
		} else if (!registr.equals(other.registr))
			return false;
		if (via_reg == null) {
			if (other.via_reg != null)
				return false;
		} else if (!via_reg.equals(other.via_reg))
			return false;
		return true;
	}
	
	
	
	

}
