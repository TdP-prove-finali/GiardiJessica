/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/

package cash_register_model;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Clienti {
	
	private final StringProperty denominazione;
	private  final StringProperty via_sede;
	private final StringProperty cap_sede;
	private final StringProperty citta_sede;
	private final StringProperty provincia_sede;
	private final StringProperty cod_fisc;
	private final StringProperty p_iva;

	
	

	public Clienti(String denominazione, String via_sede, String cap_sede, String citta_sede, String provincia_sede,
			String cod_fisc, String p_iva) {
		
		this.denominazione = new SimpleStringProperty(denominazione);
		this.via_sede = new SimpleStringProperty(via_sede);
		this.citta_sede = new SimpleStringProperty(citta_sede);
		this.cap_sede = new SimpleStringProperty(cap_sede);
		this.provincia_sede = new SimpleStringProperty(provincia_sede);
		this.cod_fisc = new SimpleStringProperty(cod_fisc);
		this.p_iva = new SimpleStringProperty(p_iva);

	}


	public String getDenominazione() {
		return denominazione.get();
	}


	public void setDenominazione(String denominazione) {
		 this.denominazione.set(denominazione);
	}


	public String getVia_sede() {
		return via_sede.get();
	}


	public void setVia_sede(String via_sede) {
		this.via_sede.set(via_sede);
	}


	public String getCap_sede() {
		return cap_sede.get();
	}


	public void setCap_sede(String cap_sede) {
		this.cap_sede.set(cap_sede);
	}

	public StringProperty capSedeProperty() {
        return cap_sede;
    }
	
	public String getCitta_sede() {
		return citta_sede.get();
	}


	public void setCitta_sede(String citta_sede) {
		this.citta_sede.set(citta_sede);
	}

	public StringProperty cittaSedeProperty() {
        return citta_sede;
    }
	
	public String getProvincia_sede() {
		return provincia_sede.get();
	}


	public void setProvincia_sede(String provincia_sede) {
		this.provincia_sede.set(provincia_sede);
	}

	public StringProperty provinciaSedeProperty() {
        return provincia_sede;
    }
	
	public String getCod_fisc() {
		return cod_fisc.get();
	}


	public void setCod_fisc(String cod_fisc) {
		this.cod_fisc.set(cod_fisc);
	}

	public StringProperty codfiscSedeProperty() {
        return cod_fisc;
    }
	
	public String getP_iva() {
		return p_iva.get();
	}


	public void setP_iva(String p_iva) {
		this.p_iva.set(p_iva);
	}
	

	
	

	public StringProperty pivaSedeProperty() {
        return p_iva;
    }
	
	public StringProperty denominazProperty() {
        return denominazione;
    }
	
	public StringProperty viaSedeProperty() {
        return via_sede;
    }


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cap_sede == null) ? 0 : cap_sede.hashCode());
		result = prime * result + ((citta_sede == null) ? 0 : citta_sede.hashCode());
		result = prime * result + ((cod_fisc == null) ? 0 : cod_fisc.hashCode());
		result = prime * result + ((denominazione == null) ? 0 : denominazione.hashCode());
		result = prime * result + ((p_iva == null) ? 0 : p_iva.hashCode());
		result = prime * result + ((provincia_sede == null) ? 0 : provincia_sede.hashCode());
		result = prime * result + ((via_sede == null) ? 0 : via_sede.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Clienti other = (Clienti) obj;
		if (cap_sede == null) {
			if (other.cap_sede != null)
				return false;
		} else if (!cap_sede.equals(other.cap_sede))
			return false;
		if (citta_sede == null) {
			if (other.citta_sede != null)
				return false;
		} else if (!citta_sede.equals(other.citta_sede))
			return false;
		if (cod_fisc == null) {
			if (other.cod_fisc != null)
				return false;
		} else if (!cod_fisc.equals(other.cod_fisc))
			return false;
		if (denominazione == null) {
			if (other.denominazione != null)
				return false;
		} else if (!denominazione.equals(other.denominazione))
			return false;
		if (p_iva == null) {
			if (other.p_iva != null)
				return false;
		} else if (!p_iva.equals(other.p_iva))
			return false;
		if (provincia_sede == null) {
			if (other.provincia_sede != null)
				return false;
		} else if (!provincia_sede.equals(other.provincia_sede))
			return false;
		if (via_sede == null) {
			if (other.via_sede != null)
				return false;
		} else if (!via_sede.equals(other.via_sede))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Clienti [denominazione=" + denominazione + ", via_sede=" + via_sede + ", cap_sede=" + cap_sede
				+ ", citta_sede=" + citta_sede + ", provincia_sede=" + provincia_sede + ", cod_fisc=" + cod_fisc
				+ ", p_iva=" + p_iva + "]";
	}
	
	
	

	
	
	

}
