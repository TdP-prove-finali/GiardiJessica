/*Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.*/
package cash_register_model;

import java.time.LocalDate;
import java.util.Date;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Interventi {
	
	private final ObjectProperty<LocalDate> data;
	private final StringProperty registratore;
	private final StringProperty cliente;
	private final StringProperty tipo_int;
	private final IntegerProperty chiusure;
	private final FloatProperty prezzo;
	private final FloatProperty costo;
	private final StringProperty note;
	public Interventi(LocalDate data,String cliente, String registratore, String tipo_int, int chiusure, float prezzo, float costo,
			String note) {
		super();
		this.data = new SimpleObjectProperty<LocalDate>(data);
		this.cliente = new SimpleStringProperty(cliente);
		this.registratore = new SimpleStringProperty(registratore);
		this.tipo_int = new SimpleStringProperty(tipo_int);
		this.chiusure = new SimpleIntegerProperty(chiusure);
		this.prezzo = new SimpleFloatProperty(prezzo);
		this.costo = new SimpleFloatProperty(costo);
		this.note = new SimpleStringProperty(note);
		
	}
	public ObjectProperty<LocalDate> getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data.set(data);
	}
	public StringProperty getRegistratore() {
		return registratore;
	}
	public void setRegistratore(String registratore) {
		this.registratore.set(registratore);
	}
	public StringProperty getTipo_int() {
		return tipo_int;
	}
	public void setTipo_int(String tipo_int) {
		this.tipo_int.set(tipo_int);
	}
	public IntegerProperty getChiusure() {
		return chiusure;
	}
	public void setChiusure(int chiusure) {
		this.chiusure.set(chiusure);
	}
	public FloatProperty getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(float prezzo) {
		this.prezzo.set(prezzo);
	}
	public FloatProperty getCosto() {
		return costo;
	}
	public void setCosto(float costo) {
		this.costo.set(costo);
	}
	public StringProperty getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note.set(note);
	}
	public StringProperty getCliente() {
		return cliente;
	}
	public void setCliente(String cliente) {
		this.cliente.set(cliente);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((chiusure == null) ? 0 : chiusure.hashCode());
		result = prime * result + ((cliente == null) ? 0 : cliente.hashCode());
		result = prime * result + ((costo == null) ? 0 : costo.hashCode());
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + ((note == null) ? 0 : note.hashCode());
		result = prime * result + ((prezzo == null) ? 0 : prezzo.hashCode());
		result = prime * result + ((registratore == null) ? 0 : registratore.hashCode());
		result = prime * result + ((tipo_int == null) ? 0 : tipo_int.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Interventi other = (Interventi) obj;
		if (chiusure == null) {
			if (other.chiusure != null)
				return false;
		} else if (!chiusure.equals(other.chiusure))
			return false;
		if (cliente == null) {
			if (other.cliente != null)
				return false;
		} else if (!cliente.equals(other.cliente))
			return false;
		if (costo == null) {
			if (other.costo != null)
				return false;
		} else if (!costo.equals(other.costo))
			return false;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (note == null) {
			if (other.note != null)
				return false;
		} else if (!note.equals(other.note))
			return false;
		if (prezzo == null) {
			if (other.prezzo != null)
				return false;
		} else if (!prezzo.equals(other.prezzo))
			return false;
		if (registratore == null) {
			if (other.registratore != null)
				return false;
		} else if (!registratore.equals(other.registratore))
			return false;
		if (tipo_int == null) {
			if (other.tipo_int != null)
				return false;
		} else if (!tipo_int.equals(other.tipo_int))
			return false;
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
